from django.contrib import admin
from ..base.admin import BaseAdmin
from .models import Wallet, WalletHistory


@admin.register(Wallet)
class WalletAdmin(BaseAdmin):
    model = Wallet


@admin.register(WalletHistory)
class WalletHistoryAdmin(BaseAdmin):
    model = WalletHistory
