from django.urls import re_path, include


api_urlpatterns = [
    re_path('', include('api.Auth.urls', ), name='auth'),
    re_path('', include('api.Admin.urls', ), name='xyzadmin'),
    re_path('', include('api.Support.urls', ), name='support'),
    re_path('', include('api.Bot.urls', ), name='bot'),
    re_path('', include('api.Chat.urls', ), name='chat'),
    re_path('', include('api.Payment.urls', ), name='payment'),
    re_path('', include('api.Subscription.urls', ), name='subscription'),
    re_path('', include('api.Token.urls', ), name='token'),
    re_path('', include('api.Wallet.urls', ), name='wallet'),
    re_path('', include('api.Training.urls', ), name='training'),
]
