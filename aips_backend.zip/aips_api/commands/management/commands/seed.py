from django.core.management.base import BaseCommand
from django.conf import settings

from django.core.files.uploadedfile import UploadedFile

from api.Auth.models import AuthUser
from api.Subscription.models import Price
from api.Bot.models import Engine, Bot


SEED_PRICE_MAPPING = {
    'bot_creation': {'value': 4.99, 'unit': '$'},
    'bot_publish': {'value': 29.99, 'unit': '$'},
    'token_purchase': {'value': 0.0001, 'unit': '$'},
    'bot_subscription_fee': {'value': 20, 'unit': '%'},
    'bot_creation_subscription': {'value': 9.99, 'unit': '$'},
}

SEED_ENGINE_MAPPING = {
    'ChatGPT-4o': {
        'thumbnail': 'assets/bot_engine/chat_gpt.png',
        'llm': 'gpt-4o',
        'description': 'ChatGPT 4o offers unparalleled conversational capabilities with its advanced language understanding and generation, ensuring seamless communication with your customers.',
        'response_time': 5,
        'accuracy': 4,
        'training_cost': 4,
        'input_cost': 1.0,
        'output_cost': 3.0
    },
    'Sonnet 3.5': {
        'thumbnail': 'assets/bot_engine/claude.png', 
        'llm': 'claude-3-5-sonnet-20240620', 
        'description': 'Sonnet 3.5 combines state-of-the-art AI technology with robust performance, delivering reliable and dynamic chatbot solutions for your business needs.',
        'response_time': 3,
        'accuracy': 5,
        'training_cost': 4,
        'input_cost': 1.0,
        'output_cost': 3.0
    },
    'Meta3 (Instruct 70B)': {
        'thumbnail': 'assets/bot_engine/meta3.png', 
        'llm': 'meta.llama3-70b-instruct-v1:0', 
        'description': 'Meta3 leverages cutting-edge AI to provide highly personalized and intuitive chatbot interactions, enhancing user engagement like never before.',
        'response_time': 4,
        'accuracy': 5,
        'training_cost': 4,
        'input_cost': 1.0,
        'output_cost': 3.0
    }
}

SEED_BOTS = {
    'AIPS': {
        'path': 'AIPS',
        'price': 0,
        'visibility': Bot.Visibility.PRIVATE,
        'status': Bot.Status.ACTIVE,
        'biography': "AIPS bot biography"
    },
    'ForeScout': {
        'path': 'forescoutevents',
        'price': 10,
        'visibility': Bot.Visibility.PRIVATE,
        'status': Bot.Status.ACTIVE,
        'biography': "ForeScout bot biography"
    },
    'Splunk': {
        'path': 'splunkevents',
        'price': 20,
        'visibility': Bot.Visibility.PRIVATE,
        'status': Bot.Status.ACTIVE,
        'biography': "Splunk bot biography"
    },
    'Tanium': {
        'path': 'taniumevents',
        'price': 30,
        'visibility': Bot.Visibility.PRIVATE,
        'status': Bot.Status.ACTIVE,
        'biography': "Tanium bot biography"
    },
}


class Command(BaseCommand):
    help = """
        command: seed 
        description: Load initial data into database
    """

    def handle(self, *args, **kwargs):
        print("Create default superuser.")

        superuser_email = settings.DEFAULT_SUPERUSER_EMAIL
        try:
            admin_user = AuthUser.objects.get(email=superuser_email)
        except AuthUser.DoesNotExist:
            admin_user = AuthUser.objects.create_superuser(
                superuser_email,
                settings.DEFAULT_SUPERUSER_PASSWORD
            )
            
        print("Loading price...")
        for name, values in SEED_PRICE_MAPPING.items():
            try:
                price = Price.objects.get(name=name)
                price.value = values['value']
                price.unit = values['unit']
                price.save()
            except Price.DoesNotExist:
                Price.objects.create(
                    name=name,
                    value=values['value'],
                    unit=values['unit'],
                )
        print("Price loaded")

        print("Loading bot engines...")
        for engine_name in Engine.EngineName.values:
            if engine_name in SEED_ENGINE_MAPPING:
                mapping = SEED_ENGINE_MAPPING[engine_name]
            else:
                mapping = SEED_ENGINE_MAPPING['ChatGPT-4o']

            try:
                engine = Engine.objects.get(name=engine_name)
                engine.thumbnail = UploadedFile(
                    file=open(f"{settings.BASE_DIR}/{mapping['thumbnail']}", 'rb')
                )
                engine.llm = mapping['llm']
                engine.description = mapping['description']
                engine.response_time = mapping['response_time']
                engine.accuracy = mapping['accuracy']
                engine.training_cost = mapping['training_cost']
                engine.input_cost = mapping['input_cost']
                engine.output_cost = mapping['output_cost']
                engine.save()
            except Engine.DoesNotExist:
                Engine.objects.create(
                    name=engine_name,
                    thumbnail=UploadedFile(
                        file=open(f"{settings.BASE_DIR}/{mapping['thumbnail']}", 'rb')
                    ),
                    llm=mapping['llm'],
                    description=mapping['description'],
                    response_time=mapping['response_time'],
                    accuracy=mapping['accuracy'],
                    training_cost=mapping['training_cost'],
                    input_cost=mapping['input_cost'],
                    output_cost=mapping['output_cost']
                )
        print("Bot engines loaded.")

        print("Create default bots...")
        default_engine = Engine.objects.get(name='ChatGPT-4o')
        for name, values in SEED_BOTS.items():
            try:
                bot = Bot.objects.get(name=name, creator=admin_user)
                bot.price = values['price']
                bot.path = values['path']
                bot.visibility = values['visibility']
                bot.status = values['status']
                bot.thumbnail = UploadedFile(
                    file=open(f"{settings.BASE_DIR}/assets/placeholder.jpg", 'rb')
                )
                bot.biography = values['biography']
                bot.save()
            except Bot.DoesNotExist:
                Bot.objects.create(
                    name=name,
                    price=values['price'],
                    path=values['path'],
                    visibility=values['visibility'],
                    status=values['status'],
                    thumbnail=UploadedFile(
                        file=open(f"{settings.BASE_DIR}/assets/placeholder.jpg", 'rb')
                    ),
                    biography=values['biography'],
                    engine=default_engine,
                    creator=admin_user
                )

        print("Default bots loaded.")
