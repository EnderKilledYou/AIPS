from django.db import models
from django.utils import timezone
from datetime import timedelta
from dateutil.relativedelta import relativedelta

from ..base.model import BaseModel
from ..Auth.models import AuthUser
from ..Payment.models import PaymentMethod
from ..Bot.models import Bot, Engine


class Price(BaseModel):
    class Name(models.TextChoices):
        BOT_CREATION = 'bot_creation'                   # 4.99
        BOT_PUBLISH = 'bot_publish'                     # 29.99
        TOKEN_PURCHASE = 'token_purchase'               # 0.0001
        BOT_SUBSCRIPTION_FEE = 'bot_subscription_fee'   # 20%
        BOT_CREATION_SUBSCRIPTION = 'bot_creation_subscription' # 9.99

    class Unit(models.TextChoices):
        DOLLAR = '$'
        PERCENT = '%'

    name = models.CharField(max_length=256, choices=Name.choices)
    value = models.FloatField()
    unit = models.CharField(max_length=32, choices=Unit.choices, default=Unit.DOLLAR)


class Service(BaseModel):
    class ServiceName(models.TextChoices):
        BOT_CREATION = 'bot_creation'           # Creator subscription
        BOT_PUBLISH = 'bot_publish'             # Creator subscription
        BOT_SUBSCRIPTION = 'bot_subscription'   # User subscription

    class Cycle(models.TextChoices):
        HOURLY = 'hourly'
        DAILY = 'daily'
        MONTHLY = 'monthly'

    name = models.CharField(max_length=256, choices=ServiceName.choices)
    price = models.FloatField()
    cycle = models.CharField(max_length=256, choices=Cycle.choices, default=Cycle.MONTHLY)
    cycle_count = models.IntegerField(default=1)
    trial_hours = models.IntegerField(default=0)
    description = models.TextField(null=True, blank=True)
    bot = models.ForeignKey(Bot, related_name='services', on_delete=models.CASCADE)

    def __str__(self):
        return self.name

    def get_renewal_offset(self):
        if self.cycle == Service.Cycle.HOURLY:
            offset = timedelta(hours=self.cycle_count)
        elif self.cycle == Service.Cycle.DAILY:
            offset = timedelta(days=self.cycle_count)
        elif self.cycle == Service.Cycle.MONTHLY:
            offset = relativedelta(months=+self.cycle_count)
        else:
            raise Exception("Invalid billing cycle")

        return offset


class Subscription(BaseModel):
    class Status(models.TextChoices):
        PENDING = 'pending'
        ACTIVE = 'active'
        EXPIRED = 'expired'
        CANCELED = 'canceled'
        SUSPENDED = 'suspended'

    price = models.FloatField()
    status = models.CharField(max_length=256, choices=Status.choices, default=Status.PENDING)
    is_cancellation_scheduled = models.BooleanField(default=False)

    last_extend_at = models.DateTimeField(blank=True, null=True)
    next_extend_at = models.DateTimeField(blank=True, null=True)

    last_payment_at = models.DateTimeField(blank=True, null=True)

    retries = models.IntegerField(default=0)
    last_retry_at = models.DateTimeField(blank=True, null=True)

    service = models.ForeignKey(Service, related_name='subscriptions', on_delete=models.CASCADE)
    subscriber = models.ForeignKey(AuthUser, related_name='subscriptions', on_delete=models.CASCADE)
    payment_method = models.ForeignKey(PaymentMethod, related_name='subscriptions', on_delete=models.CASCADE, blank=True, null=True)

