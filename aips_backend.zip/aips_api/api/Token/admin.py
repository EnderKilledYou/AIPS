from django.contrib import admin
from ..base.admin import BaseAdmin
from .models import CreatorToken, CreatorTokenHistory, BotToken, BotTokenHistory


@admin.register(CreatorToken)
class CreatorTokenAdmin(BaseAdmin):
    model = CreatorToken


@admin.register(CreatorTokenHistory)
class CreatorTokenHistoryAdmin(BaseAdmin):
    model = CreatorTokenHistory


@admin.register(BotToken)
class BotTokenAdmin(BaseAdmin):
    model = BotToken
    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)  
        form.base_fields['usage'].required = False
        form.base_fields['metrics'].required = False
        form.base_fields['bot'].required = False
        
        return form
@admin.register(BotTokenHistory)
class BotTokenHistoryAdmin(BaseAdmin):
    model = BotTokenHistory
