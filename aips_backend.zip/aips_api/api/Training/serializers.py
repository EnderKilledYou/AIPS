from rest_framework import serializers
from .models import Upload
from services.training import training_service


class UploadSerializer(serializers.ModelSerializer):
    url = serializers.CharField(read_only=True)
    fields = serializers.JSONField(read_only=True)
    method = serializers.CharField(read_only=True)

    class Meta:
        model = Upload
        exclude = ('is_deleted', 'created_at', 'modified_at',)

        extra_kwargs = {
            'bot': {'write_only': True},
            'file_name': {'write_only': True},
            'update_data': {'write_only': True},
        }

    def to_representation(self, instance):
        data = super().to_representation(instance)
        data['method'] = 'post'

        post = training_service.generate_upload_post(
            instance.bot,
            instance.file_name,
            instance.update_data
        )
        data['url'] = post['url']
        data['fields'] = post['fields']
        return data
