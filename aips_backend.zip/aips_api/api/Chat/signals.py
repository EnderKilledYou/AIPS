from django.db.models.signals import post_save
from django.dispatch import receiver
from api.Chat.models import FeedbackMessage

@receiver(post_save, sender=FeedbackMessage)
def update_last_message(sender, instance, created, **kwargs):
    if created:
        # Update the last_message field in the related channel
        channel = instance.channel
        channel.last_message = instance
        channel.save()
