from rest_framework.routers import DefaultRouter
from .views import CreatorTokenViewSet, CreatorTokenHistoryViewSet, BotTokenViewSet, BotTokenHistoryViewSet

router = DefaultRouter()
router.register(r'token/creator-tokens', CreatorTokenViewSet, basename='token-creator-tokens')
router.register(r'token/creator-token-history', CreatorTokenHistoryViewSet, basename='token-creator-token-history')
router.register(r'token/bot-tokens', BotTokenViewSet, basename='token-bot-tokens')
router.register(r'token/bot-token-history', BotTokenHistoryViewSet, basename='token-bot-token-history')
urlpatterns = router.urls
