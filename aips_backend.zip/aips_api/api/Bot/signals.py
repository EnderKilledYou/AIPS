from django.db.models.signals import post_save
from django.dispatch import receiver

from ..Subscription.models import Price, Service
from .models import Bot


@receiver(post_save, sender=Bot)
def post_save_bot(sender, instance, **kwargs):
    # For bot creator
    try:
        # Bot creation service
        price = Price.objects.get(name=Price.Name.BOT_CREATION)
        service = Service.objects.get(
            bot=instance,
            name=Service.ServiceName.BOT_CREATION
        )
        service.price = price.value
        service.save()
    except Service.DoesNotExist:
        Service.objects.create(
            name=Service.ServiceName.BOT_CREATION,
            cycle=Service.Cycle.MONTHLY,
            price=price.value,
            bot=instance
        )

    try:
        # Bot publish service
        price = Price.objects.get(name=Price.Name.BOT_PUBLISH)
        service = Service.objects.get(
            bot=instance,
            name=Service.ServiceName.BOT_PUBLISH
        )
        service.price = 0 if instance.visibility == Bot.Visibility.PRIVATE else price.value
        service.save()
    except Service.DoesNotExist:
        Service.objects.create(
            name=Service.ServiceName.BOT_PUBLISH,
            cycle=Service.Cycle.MONTHLY,
            price=0 if instance.visibility == Bot.Visibility.PRIVATE else price.value,
            bot=instance
        )

    # For bot subscribers
    try:
        # Bot subscription service
        service = Service.objects.get(
            bot=instance,
            name=Service.ServiceName.BOT_SUBSCRIPTION
        )
        service.price = instance.price
        service.save()
    except Service.DoesNotExist:
        Service.objects.create(
            name=Service.ServiceName.BOT_SUBSCRIPTION,
            cycle=Service.Cycle.MONTHLY,
            price=instance.price,
            bot=instance
        )
