from django.db import models
from ..base.model import BaseModel
from ..Bot.models import Bot


class Upload(BaseModel):
    class Status(models.TextChoices):
        PENDING = 'pending'
        UPLOADED = 'uploaded'

    file_name = models.CharField(max_length=256)
    bot = models.ForeignKey(Bot, related_name='uploads', on_delete=models.CASCADE)
    update_data = models.BooleanField(default=False)
