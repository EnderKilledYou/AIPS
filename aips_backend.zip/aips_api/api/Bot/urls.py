from rest_framework.routers import DefaultRouter
from .views import (
    BotViewSet,
    EngineViewSet,
    TrainingMaterialViewSet
)


router = DefaultRouter()
router.register(r'bot/training-materials', TrainingMaterialViewSet, basename='bot-training-materials')
router.register(r'bot/engines', EngineViewSet, basename='bot-engines')
router.register(r'bot/bots', BotViewSet, basename='bot-bots')
urlpatterns = router.urls
