# Create your models here.
import random
from uuid import uuid4
from datetime import timedelta
from django.utils import timezone
from itsdangerous import URLSafeTimedSerializer

from django.db import models
from django.conf import settings

from django.contrib.auth.models import AbstractUser, UserManager
from simple_history.models import HistoricalRecords

from ..base.model import BaseModel


class AuthUserManager(UserManager):
    def create_user(self, username, email=None, password=None, **extra_fields):
        extra_fields.setdefault("is_active", False)
        extra_fields.setdefault("is_staff", False)
        extra_fields.setdefault("is_superuser", False)
        password = password if password is not None else self.make_random_password()
        return self._create_user(username, email, password, **extra_fields)

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)

        if extra_fields.get("is_staff") is not True:
            raise ValueError("Superuser must have is_staff=True.")
        if extra_fields.get("is_superuser") is not True:
            raise ValueError("Superuser must have is_superuser=True.")

        return self._create_user(email, email, password, **extra_fields)


class UserRole(BaseModel):
    class Role(models.TextChoices):
        ADMIN = 'admin'
        SUPPORT = 'support'
        USER = 'user'

    role = models.CharField(max_length=32, choices=Role.choices)

    def __str__(self):
        return self.role


class AuthUser(AbstractUser):
    class Role(models.TextChoices):
        ADMIN = 'admin'
        SUPPORT = 'support'
        USER = 'user'

    uuid = models.UUIDField(unique=True, default=uuid4, editable=False)
    email = models.EmailField(max_length=256, unique=True)
    username = models.CharField(max_length=256, unique=True)
    role = models.CharField(max_length=32, choices=Role.choices, default=Role.USER)
    biography = models.TextField(null=True, blank=True)
    avatar = models.ImageField(upload_to='static/image/', null=True, blank=True)
    twitter = models.URLField(null=True, blank=True)
    instagram = models.URLField(null=True, blank=True)

    first_name = models.CharField(max_length=256, null=True, blank=True)
    last_name = models.CharField(max_length=256, null=True, blank=True)

    json = models.JSONField(default=dict, null=False, blank=True)

    history = HistoricalRecords()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    objects = AuthUserManager()

    class Meta:
        ordering = ['-id']

    def __str__(self):
        return self.username


class MagicLink(BaseModel):
    LINK_TYPES = (
        ('login', 'Login'),
        ('register', 'Register'),
        ('email_update', 'Email Update'),
        ('other', 'Other'),
    )

    email = models.EmailField(max_length=256)
    token = models.CharField(max_length=256)
    code = models.CharField(max_length=6)
    type = models.CharField(max_length=32, choices=LINK_TYPES, default=LINK_TYPES[0][0])
    used_count = models.IntegerField(default=0)
    expire_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        unique_together = ('email', 'type',)

    @classmethod
    def generate_code(cls, count):
        return str(random.randint(0, 10 ** count)).zfill(count)

    @classmethod
    def generate_token(cls, email):
        serializer = URLSafeTimedSerializer(settings.MAGIC_LINK_SECRET_KEY)
        return serializer.dumps(email, salt=settings.MAGIC_LINK_SECURITY_PASSWORD_SALT)

    def validate_token(self):
        try:
            serializer = URLSafeTimedSerializer(settings.MAGIC_LINK_SECRET_KEY)
            email = serializer.loads(
                self.token,
                salt=settings.MAGIC_LINK_SECURITY_PASSWORD_SALT,
                max_age=settings.MAGIC_LINK_LIFETIME
            )

            return self.email == email and self.expire_at > timezone.now()
        except Exception:
            return False

    def validate_code(self):
        return self.expire_at > timezone.now()

    def save(self, *args, **kwargs):
        self.code = self.generate_code(6)
        self.token = self.generate_token(self.email)
        self.expire_at = timezone.now() + timedelta(seconds=settings.MAGIC_LINK_LIFETIME)

        super(MagicLink, self).save(*args, **kwargs)

    def update(self):
        self.code = self.generate_code(6)
        self.token = self.generate_token(self.email)
        self.expire_at = timezone.now() + timedelta(seconds=settings.MAGIC_LINK_LIFETIME)
        self.save()
