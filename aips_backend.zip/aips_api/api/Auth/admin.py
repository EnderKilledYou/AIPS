from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin
from django.utils.translation import gettext_lazy as _
from .models import AuthUser, MagicLink


@admin.register(AuthUser)
class UserAdmin(DjangoUserAdmin):
    """Define admin model for custom User model with no email field."""

    fieldsets = (
        (None, {'fields': ('email', 'username')}),
        (_('Personal info'), {'fields': ('first_name', 'last_name', 'avatar')}),
        (_('Permissions'), {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions', 'role')}),
        (_('Important dates'), {'fields': ('last_login', 'date_joined')}),
        (_('Extra info'), {'fields': ('biography', 'twitter', 'instagram', 'json')}),
    )
    add_fieldsets = (
        (_('Personal info'), {'fields': ('email', 'username', 'password1', 'password2', 'first_name', 'last_name'), }),
        (_('Permissions'), {'fields': ('role',)}),
    )

    list_display = ('username', 'email', 'role', 'twitter', 'instagram', 'is_active', 'is_staff', 'last_login', 'date_joined')
    search_fields = ('username', 'email', )
    ordering = ('-date_joined',)


@admin.register(MagicLink)
class MagicLinkAdmin(admin.ModelAdmin):
    model = MagicLink
    readonly_fields = ('token', 'code')

    list_display = ('email', 'token', 'code', 'type', 'expire_at', 'created_at', 'modified_at')
    list_filter = ("type", )




