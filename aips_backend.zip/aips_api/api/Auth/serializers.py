from django.contrib.auth import get_user_model
from rest_framework import serializers
from djoser.conf import settings
from djoser.serializers import \
    UserSerializer, UserCreateSerializer, ActivationSerializer, SendEmailResetSerializer, \
    PasswordResetConfirmSerializer, SetPasswordSerializer, SetUsernameSerializer

from .models import MagicLink
from ..Wallet.serializers import WalletSerializer
from  ..Token.serializers import CreatorTokenSerializer
from ..Bot.models import Bot
from ..Payment.models import PaymentHistory
from ..Payment.serializers import PaymentHistorySerializer
from django.db.models import Count, Max, Q, Subquery, OuterRef, F , Value , CharField
from ..Chat.models import BotMessage,FeedbackChannel
from itertools import chain
from operator import itemgetter


AuthUser = get_user_model()


class RegisterSerializer(serializers.Serializer):
    email = serializers.EmailField()
    username = serializers.CharField(max_length=256)


class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField()


class TokenVerifySerializer(serializers.Serializer):
    token = serializers.CharField()
    type = serializers.ChoiceField(choices=MagicLink.LINK_TYPES)


class RefreshSerializer(serializers.Serializer):
    refresh = serializers.CharField()


class BasicRegisterSerializer(UserCreateSerializer):
    class Meta:
        model = AuthUser
        fields = (
            'first_name',
            'last_name',
            'username',
            'password',
        )


class ProfileSerializer(UserSerializer):
    wallet = WalletSerializer(read_only=True)
    token = CreatorTokenSerializer(read_only=True)

    class Meta:
        model = AuthUser
        depth = 1
        fields = (
            settings.USER_ID_FIELD,
            settings.LOGIN_FIELD,
            'email',
            'biography',
            'avatar',
            'twitter',
            'instagram',
            'wallet',
            'token',
            'json',
            'role',
        )
        read_only_fields = (
            settings.USER_ID_FIELD,
            settings.LOGIN_FIELD,
            'email',
            'wallet',
            'token',
            'role',
        )


class CustomUserSerializer(UserSerializer):
    class Meta:
        model = AuthUser
        fields = (
            settings.USER_ID_FIELD,
            settings.LOGIN_FIELD,
            'email',
            'biography',
            'avatar',
            'twitter',
            'instagram',
            'json',
            'role',
        )
        read_only_fields = (settings.USER_ID_FIELD, settings.LOGIN_FIELD, 'email', 'role')


class RegisterConfirmSerializer(ActivationSerializer):
    pass


class PasswordResetSerializer(SendEmailResetSerializer):
    pass


class PasswordConfirmSerializer(PasswordResetConfirmSerializer):
    pass


class PasswordUpdateSerializer(SetPasswordSerializer):
    pass

class UsernameUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AuthUser
        fields = (settings.LOGIN_FIELD, )

class EmailUpdateSerializer(SetUsernameSerializer):
    pass


class MinimalUserSerializer(UserSerializer):
    token = CreatorTokenSerializer(read_only=True)
    class Meta:
        model = AuthUser
        fields = (
            settings.USER_ID_FIELD,
            settings.LOGIN_FIELD,
            'avatar',
            'token'
        )
        read_only_fields = (settings.USER_ID_FIELD, settings.LOGIN_FIELD, 'token')

class MessagesSupportSerializer(serializers.Serializer):
    entity = serializers.CharField()
    id = serializers.UUIDField()
    name = serializers.CharField()
    letest_message = serializers.CharField()
    message_created_at = serializers.DateTimeField()

class SupportUserSerializer(UserSerializer):
    class Meta:
        model = AuthUser
        fields = (
            settings.USER_ID_FIELD,
            settings.LOGIN_FIELD,
            'avatar',
            'date_joined'
        )
        read_only_fields = (settings.USER_ID_FIELD, settings.LOGIN_FIELD)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        transactions = PaymentHistory.objects.filter(payer_email = instance.email)

        latest_created_at_subquery = BotMessage.objects.filter(
            bot=OuterRef('bot'),
            user=instance
        ).order_by('-created_at').values('created_at')[:1]
        latest_bot_messages = BotMessage.objects.filter(user=instance).annotate(
            latest_created_at=Subquery(latest_created_at_subquery),
            bot_name=F('bot__name')
        )
        latest_messages = latest_bot_messages.filter(
            created_at=F('latest_created_at')
        )
        bot_messages = latest_messages.values('bot_name').annotate(
            entity=Value('Bot',output_field=CharField()),
            letest_message=Max('prompt_text'),
            id=F('bot__id'),
            name=F('bot__name'),
            message_created_at=F('created_at')
        ).order_by('-latest_created_at')

        user_message =  FeedbackChannel.objects.filter(bot__creator=instance).values(
            'id','user__username','last_message__message','last_message__created_at').annotate(
            entity=Value('User',output_field=CharField()),
            letest_message=Max('last_message__message'),
            name=F('user__username'),
            message_created_at=F('last_message__created_at')
        ).order_by('-last_message__created_at')

        bot_messages_list = list(bot_messages)
        user_messages_list = list(user_message)

        filtered_bot_messages = [msg for msg in bot_messages_list if msg['message_created_at'] is not None]
        filtered_user_messages = [msg for msg in user_messages_list if msg['message_created_at'] is not None]
        combined_messages = sorted(
            chain(filtered_bot_messages,filtered_user_messages),
            key=itemgetter('message_created_at'),
            reverse=True
        )
        data["bot_count"] = instance.bots.count()
        data["transactions"] = PaymentHistorySerializer(transactions, many=True).data
        data["messages"] = MessagesSupportSerializer(combined_messages, many=True).data
        return data

class RankUserSerializer(UserSerializer):
    message_count = serializers.IntegerField()

    class Meta:
        model = AuthUser
        fields = (
            settings.USER_ID_FIELD,
            settings.LOGIN_FIELD,
            'avatar',
            'message_count'
        )