import stripe
from django.conf import settings
from api.Payment.models import PaymentMethod


class PaymentService:
    def __init__(self):
        self.stripe = stripe
        self.stripe.api_key = settings.STRIPE_SECRET_KEY

    def create_customer(self, customer_data):
        search_results = self.stripe.Customer.search(query=f"email:'{customer_data['email']}'")
        if len(search_results) == 0:
            customer = self.stripe.Customer.create(
                email=customer_data['email'],
                metadata=customer_data['metadata']
            )
            return customer
        else:
            customer = self.stripe.Customer.modify(
                id=search_results.data[0].id,
                metadata=customer_data['metadata']
            )
            return customer

    def create_payment_session(self, payment_data):
        customer_data = {
            'email': payment_data['email'],
            'metadata': {'status': 'Pending'}
        }
        customer = self.create_customer(customer_data)

        pi_metadata = {
            'customer_email': payment_data['email'],
            'source': payment_data['source'],
        }

        payment_intent = self.stripe.PaymentIntent.create(
            amount=int(round(payment_data['amount'] * 100)),
            currency="usd",
            customer=customer.id,
            automatic_payment_methods={
                'enabled': True,
                'allow_redirects': 'never'
            },
            setup_future_usage='off_session',
            # payment_method_types=['card', 'us_bank_account'],
            metadata=pi_metadata
        )

        return payment_intent

    def verify_payment_status(self, payment_intent_id, amount):
        payment_intent = self.stripe.PaymentIntent.retrieve(payment_intent_id)
        if payment_intent is not None:
            return payment_intent.amount_received == int(round(amount * 100))
        return False

    def complete_payment_session(self, payment_intent_id):
        payment_intent = self.stripe.PaymentIntent.retrieve(payment_intent_id)

        self.stripe.Customer.modify(
            id=payment_intent.customer,
            metadata={'status': 'Active'}
        )

        payment_method = self.stripe.PaymentMethod.retrieve(payment_intent.payment_method)

        return {
            "customer_id": payment_intent.customer,
            "payment_method_id": payment_method.id,
            "last4_digits": payment_method.card.last4 if payment_method.type == 'card' else '****',
            "type": PaymentMethod.Type.CARD if payment_method.type == 'card' else PaymentMethod.Type.LINK
        }

    def instant_charge(self, amount, customer, payment_method, metadata):
        pi_metadata = {
            'customer_email': metadata['email'],
            'source': metadata['source'],
        }

        payment = self.stripe.PaymentIntent.create(
            amount=int(amount * 100),
            currency='usd',
            customer=customer,
            payment_method=payment_method,
            automatic_payment_methods={
                'enabled': True,
                'allow_redirects': 'never'
            },
            confirm=True,
            metadata=pi_metadata
        )
        return payment
    
    def create_connect_account(self, email):
        account = self.stripe.Account.create(
            type="express",
            country="US",
            email=email
        )
        return account
    
    def get_connect_account_info(self, account_id):
        account = self.stripe.Account.retrieve(account_id)
        return account
    
    def generate_payout_session(self, account_id):
        account_session = self.stripe.AccountSession.create(
            account=account_id,
            components={
                'account_onboarding': {
                    "enabled": True
                }
            }
        )
        return account_session
    
    def create_payout(self, amount, account_id):
        self.stripe.Transfer.create(
            amount=amount,
            currency="usd",
            destination=account_id,
        )
        payout = self.stripe.Payout.create(
            amount=amount,
            currency="usd",
            stripe_account=account_id
        )
        bank_info = self.stripe.Account.retrieve_external_account(account_id, payout.destination)
        return bank_info

    def payout(self, amount, payment_method):
        ...


payment_service = PaymentService()
