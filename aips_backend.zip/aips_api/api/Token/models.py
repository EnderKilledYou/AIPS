from django.db import models
from ..base.model import BaseModel
from ..Auth.models import AuthUser
from ..Bot.models import Bot
from ..Chat.models import BotMessage


class CreatorToken(BaseModel):
    balance = models.IntegerField(default=0)
    usage = models.IntegerField(default=0)
    user = models.OneToOneField(AuthUser, related_name='token', on_delete=models.CASCADE)


class CreatorTokenHistory(BaseModel):
    amount = models.IntegerField(default=0)
    reason = models.CharField(max_length=256)
    token = models.ForeignKey(CreatorToken, related_name='history', on_delete=models.CASCADE)

    class Meta:
        verbose_name = 'Creator Token History'
        verbose_name_plural = 'Creator Token History'


class BotToken(BaseModel):
    limit = models.IntegerField(default=10000)
    usage = models.IntegerField(default=0)
    metrics = models.JSONField(default=dict)
    bot = models.OneToOneField(Bot, related_name="token", on_delete=models.CASCADE)


class BotTokenHistory(BaseModel):
    usage = models.IntegerField(default=0)
    message = models.OneToOneField(BotMessage, related_name="history", on_delete=models.CASCADE)

    class Meta:
        verbose_name = 'Bot Token History'
        verbose_name_plural = 'Bot Token History'
