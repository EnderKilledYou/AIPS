from drf_spectacular.utils import extend_schema
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from ..base.permissions import IsAdminUser
from rest_framework_simplejwt.authentication import JWTAuthentication

from rest_framework import status
from rest_framework.response import Response

from .serializers import PricingSerializer

# Create your views here.
from ..Subscription.models import Price


@extend_schema(
    tags=["Admin"]
)
class PricingUpdateView(APIView):
    serializer_class = PricingSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated, IsAdminUser]

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)

        bot_creation = serializer.validated_data['bot_creation']
        bot_publish = serializer.validated_data['bot_publish']
        token_purchase = serializer.validated_data['token_purchase']
        bot_subscription_fee = serializer.validated_data['bot_subscription_fee']

        price = Price.objects.get(name=Price.Name.BOT_CREATION)
        price.value = bot_creation
        price.save()

        price = Price.objects.get(name=Price.Name.BOT_PUBLISH)
        price.value = bot_publish
        price.save()

        price = Price.objects.get(name=Price.Name.TOKEN_PURCHASE)
        price.value = token_purchase
        price.save()

        price = Price.objects.get(name=Price.Name.BOT_SUBSCRIPTION_FEE)
        price.value = bot_subscription_fee
        price.save()

        return Response({
            "bot_creation": bot_creation,
            "bot_publish": bot_publish,
            "token_purchase": token_purchase,
            "bot_subscription_fee": bot_subscription_fee
        }, status=status.HTTP_200_OK)
    
    def get(self, request):
        return Response({
            "bot_creation": Price.objects.get(name=Price.Name.BOT_CREATION).value,
            "bot_publish": Price.objects.get(name=Price.Name.BOT_PUBLISH).value,
            "token_purchase": Price.objects.get(name=Price.Name.TOKEN_PURCHASE).value,
            "bot_subscription_fee": Price.objects.get(name=Price.Name.BOT_SUBSCRIPTION_FEE).value
        }, status=status.HTTP_200_OK)
