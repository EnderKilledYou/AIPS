from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import MyWalletView, CashOutView, WalletHistoryView, WalletSessionView

router = DefaultRouter()

urlpatterns = router.urls + [
    path('wallet', MyWalletView.as_view(), name="wallet-wallet"),
    path('wallet/session', WalletSessionView.as_view(), name="wallet-session"),
    path('wallet/cash-out', CashOutView.as_view(), name="wallet-cash-out"),
    path('wallet/history', WalletHistoryView.as_view(), name="wallet-history"),
]
