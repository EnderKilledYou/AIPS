from rest_framework.routers import DefaultRouter
from .views import UploadViewSet

router = DefaultRouter()
router.register(r'training/upload', UploadViewSet, basename='training-upload')
urlpatterns = router.urls
