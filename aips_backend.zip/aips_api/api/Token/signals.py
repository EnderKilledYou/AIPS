from django.db.models.signals import post_save
from django.dispatch import receiver

from ..Auth.models import AuthUser
from ..Bot.models import Bot

from .models import CreatorToken, BotToken


@receiver(post_save, sender=AuthUser)
def post_save_user(sender, instance, **kwargs):
    try:
        CreatorToken.objects.get(user=instance)
    except CreatorToken.DoesNotExist:
        CreatorToken.objects.create(user=instance)


@receiver(post_save, sender=Bot)
def post_save_bot(sender, instance, **kwargs):
    try:
        BotToken.objects.get(bot=instance)
    except BotToken.DoesNotExist:
        BotToken.objects.create(bot=instance)
