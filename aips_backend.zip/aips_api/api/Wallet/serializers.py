from rest_framework import serializers
from .models import Wallet, WalletHistory


class WalletSerializer(serializers.ModelSerializer):

    class Meta:
        model = Wallet
        fields = ('balance', )
        read_only_fields = ('balance', )

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data


class CashOutSerializer(serializers.Serializer):
    amount = serializers.FloatField(min_value=1, write_only=True)


class WalletHistorySerializer(serializers.ModelSerializer):

    class Meta:
        model = WalletHistory
        fields = ('id', 'amount', 'last4_digit', 'description', 'created_at')

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data
