from django.urls import include, path, reverse
from rest_framework import status

from rest_framework.test import APITestCase, URLPatternsTestCase

from .models import AuthUser

# Create your tests here.


class AuthTestClass(APITestCase, URLPatternsTestCase):
    urlpatterns = [
        path('.', include('api.Auth.urls')),
    ]

    def setUp(self):
        # Setup run before every test method.
        pass

    def tearDown(self):
        # Clean up run after every test method.
        pass

    def test_create_account_success(self):
        url = reverse('register')
        response = self.client.post(url, {'username': 'test', 'email': 'test@test.com'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_create_account_failure_with_invalid_email_address(self):
        url = reverse('register')
        response = self.client.post(url, {'username': 'test', 'email': 'invalid email'})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_create_account_failure_with_empty_request_body(self):
        url = reverse('register')
        response = self.client.post(url, {})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_login_success(self):
        AuthUser.objects.create(
            username='test',
            email='test@test.com',
            is_active=True
        )

        url = reverse('login')
        response = self.client.post(url, {'email': 'test@test.com'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_login_failure_with_email_not_found(self):
        url = reverse('login')
        response = self.client.post(url, {'email': 'test@test.com'})
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)