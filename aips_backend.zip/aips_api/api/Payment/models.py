from django.db import models
from ..base.model import BaseModel
from ..Auth.models import AuthUser


class PaymentMethod(BaseModel):
    class Type(models.TextChoices):
        CARD = 'card'
        APPLE_PAY = 'apple_pay'
        GOOGLE_PAY = 'google_pay'
        LINK = 'link'
        
    type = models.CharField(max_length=64, choices=Type.choices, default=Type.CARD)
    email = models.EmailField(max_length=256, null=True, blank=True)
    stripe_customer_id = models.CharField(max_length=256, null=True, blank=True)
    stripe_payment_method_id = models.CharField(max_length=256, null=True, blank=True)
    last4_digits = models.CharField(max_length=256, null=True, blank=True)
    first_name = models.CharField(max_length=256, blank=True, null=True)
    last_name = models.CharField(max_length=256, blank=True, null=True)
    address1 = models.CharField(max_length=256, blank=True, null=True)
    address2 = models.CharField(max_length=256, blank=True, null=True)
    zip_code = models.CharField(max_length=12, blank=True, null=True)
    city = models.CharField(max_length=256, blank=True, null=True)
    state = models.CharField(max_length=2, blank=True, null=True)
    owner = models.ForeignKey(AuthUser, related_name='payment_methods', on_delete=models.CASCADE)

    def __str__(self):
        return self.last4_digits if self.last4_digits is not None else '-'


class PaymentHistory(BaseModel):
    payer_email = models.EmailField(max_length=256)
    amount = models.CharField(max_length=256)
    description = models.CharField(max_length=1024, blank=True, null=True)
    fee = models.CharField(max_length=256, null=True, blank=True)
    payment_method = models.ForeignKey(PaymentMethod, related_name='payment_history', on_delete=models.CASCADE)


class PaymentSession(BaseModel):
    class Status(models.TextChoices):
        PENDING = 'pending'
        SUCCESS = 'success'
        FAILED = 'failed'

    class Type(models.TextChoices):
        BOT_CREATION = 'bot_creation'
        BOT_SUBSCRIPTION = 'bot_subscription'
        TOKEN_PURCHASE = 'token_purchase'

    amount = models.FloatField()
    status = models.CharField(max_length=32, default=Status.PENDING)
    type = models.CharField(max_length=32, choices=Type.choices, default=Type.BOT_CREATION)
    description = models.CharField(max_length=1024, blank=True, null=True)
    stripe_payment_intent_id = models.CharField(max_length=256)
    stripe_customer_id = models.CharField(max_length=256)
    stripe_client_secret = models.CharField(max_length=1024)
    user = models.ForeignKey(AuthUser, related_name='payment_sessions', on_delete=models.CASCADE)
