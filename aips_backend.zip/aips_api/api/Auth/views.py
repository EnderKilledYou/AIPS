from django.contrib.auth import get_user_model
from rest_framework import views, status
from rest_framework.response import Response
from rest_framework.viewsets import ViewSet
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.exceptions import TokenError
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from drf_spectacular.utils import extend_schema

from .serializers import (
    RegisterSerializer,
    LoginSerializer,
    TokenVerifySerializer,
    RefreshSerializer,
    BasicRegisterSerializer,
    ProfileSerializer,
    CustomUserSerializer,
    RegisterConfirmSerializer,
    PasswordResetSerializer,
    PasswordConfirmSerializer,
    PasswordUpdateSerializer,
    EmailUpdateSerializer,
    UsernameUpdateSerializer
)

from djoser.views import UserViewSet as BaseUserViewSet
from .models import MagicLink
from utils.email import send_signup_email, send_signin_email

AuthUser = get_user_model()


@extend_schema(
        tags=["Auth"]
    )
class TokenRegisterViewSet(ViewSet):
    authentication_classes = []
    serializer_class = RegisterSerializer

    def create(self, request, *args, **kwargs):
        # Check user exist
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)

        MagicLink.objects.filter(email=serializer.validated_data['email'], type='register').delete()

        try:
            AuthUser.objects.exclude(email__iexact=serializer.validated_data['email']).get(username=serializer.validated_data['username'])
            return Response(
                {'message': 'Username already taken by other user.', 'success': False},
                status=status.HTTP_409_CONFLICT
            )
        except AuthUser.DoesNotExist:
            pass

        try:
            user = AuthUser.objects.get(email__iexact=serializer.validated_data['email'])
            if user.is_active:
                return Response(
                    {'message': 'User already exist', 'success': False},
                    status=status.HTTP_409_CONFLICT
                )
        except AuthUser.DoesNotExist:
            user = AuthUser.objects.create_user(**serializer.validated_data)

        link = MagicLink.objects.create(
            email=serializer.validated_data['email'],
            type='register'
        )
        send_signup_email(user.email, link.token)

        return Response(
            {'message': 'Registration link sent', 'success': True},
            status=status.HTTP_200_OK
        )


@extend_schema(
        tags=["Auth"]
    )
class TokenLoginViewSet(ViewSet):
    authentication_classes = []
    serializer_class = LoginSerializer

    def create(self, request, *args, **kwargs):
        # Check user exist
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)

        MagicLink.objects.filter(email=serializer.validated_data['email'], type='login').delete()

        try:
            user = AuthUser.objects.get(email__iexact=serializer.validated_data['email'], is_active=True)

            link = MagicLink.objects.create(
                email=serializer.validated_data['email'],
                type='login'
            )
            send_signin_email(user.email, link.token)
            return Response(
                {'message': 'Login link sent', 'success': True},
                status=status.HTTP_200_OK
            )
        except AuthUser.DoesNotExist:
            return Response(
                {'message': 'User not found', 'success': False},
                status=status.HTTP_404_NOT_FOUND
            )


@extend_schema(
        tags=["Auth"]
    )
class TokenVerifyViewSet(ViewSet):
    authentication_classes = []
    serializer_class = TokenVerifySerializer

    def create(self, request, *args, **kwargs):
        # Check user exist
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)

        try:
            link = MagicLink.objects.get(
                token=serializer.validated_data['token'],
                type=serializer.validated_data['type']
            )
            if not link.validate_token():
                return Response(
                    {'message': 'Invalid token or expired', 'success': False},
                    status=status.HTTP_400_BAD_REQUEST
                )

            user = AuthUser.objects.get(email__iexact=link.email)

            if serializer.validated_data['type'] == 'register':
                user.is_active = True
                user.save()
            else:
                if not user.is_active:
                    return Response(
                        {'message': 'Active user not found', 'success': False},
                        status=status.HTTP_404_NOT_FOUND
                    )

            refresh = RefreshToken.for_user(user)

            link.delete()

            return Response(
                {'access_token': str(refresh.access_token), 'refresh_token': str(refresh), 'success': True},
                status=status.HTTP_200_OK
            )
        except MagicLink.DoesNotExist:
            return Response(
                {'message': 'Token not found', 'success': False},
                status=status.HTTP_404_NOT_FOUND
            )
        
@extend_schema(
        tags=["Auth"]
    )
class TokenResendViewSet(ViewSet):
    authentication_classes = []
    serializer_class = TokenVerifySerializer

    def create(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)

        try:
            link = MagicLink.objects.get(
                token=serializer.validated_data['token'],
                type=serializer.validated_data['type']
            )

            link.delete()

            new_link = MagicLink.objects.create(
                email=link.email,
                type=link.type
            )

            if link.type == 'login':
                send_signin_email(link.email, new_link.token)
            else:
                send_signup_email(link.email, new_link.token)

            return Response(
                {'success': True},
                status=status.HTTP_200_OK
            )
        except MagicLink.DoesNotExist:
            return Response(
                {'message': 'Token not found', 'success': False},
                status=status.HTTP_404_NOT_FOUND
            )


@extend_schema(
    tags=["Auth"]
)
class OTPRegisterViewSet(BaseUserViewSet):
    authentication_classes = []
    serializer_class = RegisterSerializer


@extend_schema(
    tags=["Auth"]
)
class OTPLoginViewSet(BaseUserViewSet):
    authentication_classes = []
    serializer_class = RegisterSerializer

@extend_schema(
        tags=["Auth"]
    )
class BasicRegisterViewSet(BaseUserViewSet):
    authentication_classes = []
    serializer_class = BasicRegisterSerializer


@extend_schema(
        tags=["Auth"]
    )
class BasicLoginView(TokenObtainPairView):
    pass


@extend_schema(
        tags=["Auth"]
    )
class LogoutView(views.APIView):
    authentication_classes = (JWTAuthentication,)
    serializer_class = RefreshSerializer

    def post(self, request, *args, **kwargs):
        try:
            token = RefreshToken(request.data.get('refresh'))
            token.blacklist()
            return Response(
                {"detail": "Successfully logged out."},
                status=status.HTTP_200_OK
            )
        except TokenError:
            return Response(
                {"detail": "Invalid refresh token."},
                status=status.HTTP_400_BAD_REQUEST
            )


@extend_schema(
        tags=["Auth"]
    )
class RefreshView(TokenRefreshView):
    pass


@extend_schema(
        tags=["Auth"]
    )
class RegisterConfirmViewSet(BaseUserViewSet):
    serializer_class = RegisterConfirmSerializer
    http_method_names = ['post']

    def get_serializer_class(self):
        return self.serializer_class


@extend_schema(
        tags=["Auth"]
    )
class PasswordResetViewSet(BaseUserViewSet):
    serializer_class = PasswordResetSerializer
    http_method_names = ['post']

    def get_serializer_class(self):
        return self.serializer_class


@extend_schema(
        tags=["Auth"]
    )
class PasswordConfirmViewSet(BaseUserViewSet):
    serializer_class = PasswordConfirmSerializer
    http_method_names = ['post']

    def get_serializer_class(self):
        return self.serializer_class


@extend_schema(
        tags=["Profile"]
    )
class ProfileViewSet(BaseUserViewSet):
    serializer_class = ProfileSerializer
    http_method_names = ['get', 'put', 'patch']

    def get_serializer_class(self):
        return self.serializer_class

    def perform_update(self, serializer):
        serializer.save()


@extend_schema(
        tags=["Profile"]
    )
class PasswordUpdateViewSet(BaseUserViewSet):
    serializer_class = PasswordUpdateSerializer
    http_method_names = ['post']

    def get_serializer_class(self):
        return self.serializer_class

@extend_schema(
        tags=["Profile"]
    )
class UsernameUpdateViewset(BaseUserViewSet):
    serializer_class = UsernameUpdateSerializer
    http_method_names = ['put']

    def get_serializer_class(self):
        return self.serializer_class
    
    def set_username(self, request, *args, **kwargs):
        try:
            AuthUser.objects.exclude(id=request.user.id).get(username=request.data['username'])
            return Response(
                {'message': 'Username already taken by other user.'},
                status=status.HTTP_409_CONFLICT
            )
        except AuthUser.DoesNotExist:
            pass
        
        request.user.username = request.data['username']
        request.user.save()
        return Response(
            {'message': 'Success'},
            status=status.HTTP_200_OK
        )

@extend_schema(
        tags=["Profile"]
    )
class EmailUpdateViewSet(BaseUserViewSet):
    serializer_class = EmailUpdateSerializer
    http_method_names = ['post']

    def get_serializer_class(self):
        return self.serializer_class


@extend_schema(
        tags=["User"]
    )
class UserViewSet(BaseUserViewSet):
    serializer_class = CustomUserSerializer
    http_method_names = ['post', 'get', 'put', 'patch', 'delete']

    def get_serializer_class(self):
        return self.serializer_class
