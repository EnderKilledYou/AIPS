from django.contrib import admin
from ..base.admin import BaseAdmin
from .models import Price, Service, Subscription


@admin.register(Price)
class PriceAdmin(admin.ModelAdmin):
    list_display = ('name', 'value', 'unit', 'modified_at')


@admin.register(Service)
class ServiceAdmin(BaseAdmin):
    model = Service


@admin.register(Subscription)
class SubscriptionAdmin(BaseAdmin):
    model = Subscription
