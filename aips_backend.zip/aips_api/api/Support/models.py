from django.db import models
from ..base.model import BaseModel
from ..Auth.models import AuthUser

class TagWall(BaseModel):
    content = models.TextField()
    user = models.ForeignKey(AuthUser, related_name='tag', on_delete=models.CASCADE)