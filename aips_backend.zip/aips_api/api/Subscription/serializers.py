from rest_framework import serializers
from .models import Service, Subscription


class ServiceSerializer(serializers.ModelSerializer):

    class Meta:
        model = Service
        exclude = ('is_deleted',)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data


class SubscriptionSerializer(serializers.ModelSerializer):

    class Meta:
        model = Subscription
        exclude = ('is_deleted',)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data
