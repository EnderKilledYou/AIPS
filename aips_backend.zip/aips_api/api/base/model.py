import uuid
from django.db import models


class BaseModel(models.Model):
    """Base model to be used to inject common fields.
    """
    id = models.UUIDField(primary_key=True, unique=True, default=uuid.uuid4, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)
    is_deleted = models.BooleanField(default=False)

    class Meta:
        abstract = True
        ordering = ('-created_at',)
        get_latest_by = ['created_at', 'modified_at']

    def __str__(self):
        return f"{self.id}"
