import uuid
from django.db import models
from ..base.model import BaseModel
from ..Auth.models import AuthUser


class Engine(BaseModel):
    class EngineName(models.TextChoices):
        CHATGPT = 'ChatGPT-4o'
        SONNET = 'Sonnet 3.5'
        META3 = 'Meta3 (Instruct 70B)'

    name = models.CharField(max_length=256, unique=True, choices=EngineName.choices)
    description = models.TextField(null=True, blank=True)
    thumbnail = models.ImageField(upload_to='static/engine/thumbnail/', null=True, blank=True)
    llm = models.CharField(max_length=256, blank=True)
    response_time = models.IntegerField(default=0)
    accuracy = models.IntegerField(default=0)
    training_cost = models.IntegerField(default=0)
    input_cost = models.FloatField(default=0.0)
    output_cost = models.FloatField(default=0.0)

    def __str__(self):
        return self.name


class Bot(BaseModel):
    class Visibility(models.TextChoices):
        PRIVATE = 'private'
        INVITE_ONLY = 'invite_only'
        PUBLIC = 'public'

    class Status(models.TextChoices):
        CONFIGURE = 'configure'
        PENDING_TRAIN = 'pending_train'  # Wait payment for train
        TRAIN = 'train'
        ACTIVE = 'active'
        DISABLED = 'disabled'

    name = models.CharField(max_length=256)
    price = models.FloatField(default=0.0)
    path = models.CharField(max_length=256, null=True, blank=True)
    thumbnail = models.ImageField(upload_to='static/bot/thumbnail/', null=True, blank=True)
    biography = models.TextField(null=True, blank=True)
    anchor_prompt = models.TextField(null=True, blank=True)
    visibility = models.CharField(max_length=256, choices=Visibility.choices)
    status = models.CharField(max_length=256, choices=Status.choices, default=Status.CONFIGURE)

    include_child_page = models.BooleanField(default=True)
    restrict_response = models.BooleanField(default=True)
    retain_conversational_context = models.BooleanField(default=True)

    task_id = models.UUIDField(blank=True, null=True)

    engine = models.ForeignKey(Engine, related_name='bots', on_delete=models.CASCADE)
    creator = models.ForeignKey(AuthUser, related_name='bots', on_delete=models.CASCADE)

    def __str__(self):
        return self.name


class TrainingMaterial(BaseModel):
    class Type(models.TextChoices):
        URL = 'url'
        FILE = 'file'
        CHILDURL = 'child'
    type = models.CharField(max_length=256, choices = Type.choices, default = Type.URL)
    url = models.URLField()
    bot = models.ForeignKey(Bot, related_name="training_materials", on_delete=models.CASCADE)
    
