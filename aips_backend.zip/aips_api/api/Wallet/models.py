from django.db import models
from ..base.model import BaseModel
from ..Auth.models import AuthUser


class Wallet(BaseModel):
    balance = models.FloatField(default=0)
    stripe_account_id = models.CharField(max_length=256, null=True, blank=True)
    owner = models.OneToOneField(AuthUser, related_name='wallet', on_delete=models.CASCADE)


class WalletHistory(BaseModel):
    amount = models.FloatField(default=0)
    description = models.TextField(null=True, blank=True)
    last4_digit = models.CharField(max_length=256, null=True, blank=True)
    wallet = models.ForeignKey(Wallet, related_name='history', on_delete=models.CASCADE)

    class Meta:
        verbose_name = 'Wallet History'
        verbose_name_plural = 'Wallet History'
        ordering = ['-created_at']
