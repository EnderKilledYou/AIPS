from rest_framework import serializers
from rest_framework import status

from .models import Bot, Engine, TrainingMaterial

from ..Auth.serializers import MinimalUserSerializer
from ..Payment.serializers import StartPaymentSessionSerializer, CompletePaymentSessionSerializer
from ..Subscription.models import Subscription
from  ..Token.serializers import BotTokenMinimalSerializer


class EngineSerializer(serializers.ModelSerializer):

    class Meta:
        model = Engine
        exclude = ('is_deleted',)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data


class TrainingMaterialSerializer(serializers.ModelSerializer):

    class Meta:
        model = TrainingMaterial
        exclude = ('is_deleted',)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data

class TrainingMaterialSublinkSerializer(serializers.Serializer):
    data=serializers.ListField(child=serializers.CharField(), write_only=True)
    bot_id=serializers.UUIDField(write_only=True)

class BotSerializer(serializers.ModelSerializer):
    engine = EngineSerializer(read_only=True)
    engine_id = serializers.UUIDField(write_only=True)
    training_materials = TrainingMaterialSerializer(many=True, read_only=True)
    creator = MinimalUserSerializer(read_only=True)
    token = BotTokenMinimalSerializer(read_only=True)

    class Meta:
        model = Bot
        depth = 1
        exclude = ('is_deleted', 'path', 'task_id',)

        read_only_fields = ('engine', 'training_materials', 'creator', 'status',)
    
    def create(self, validated_data):
        try:
            validated_data['engine'] = Engine.objects.get(pk=validated_data['engine_id'])
            validated_data.pop('engine_id')
        except Engine.DoesNotExist:
            raise serializers.ValidationError(
                {'engine_id': 'Invalid engine id'},
                code=status.HTTP_400_BAD_REQUEST
            )

        validated_data['creator'] = self.context['request'].user
        return super().create(validated_data)
    
    def to_representation(self, instance):
        data = super().to_representation(instance)

        request = self.context.get('request', None)
        if request.user and request.user.is_authenticated:
            user = request.user
            active_subscription = Subscription.objects.filter(subscriber=user, status=Subscription.Status.ACTIVE, service__bot=instance).last()
            data['created'] = user == instance.creator
            data['subscribed'] = (user != instance.creator) and active_subscription is not None
            data['cancellation_scheduled'] = active_subscription is not None and active_subscription.is_cancellation_scheduled 
        return data


class BotMinimalSerializer(serializers.ModelSerializer):
    creator = MinimalUserSerializer(read_only=True)

    class Meta:
        model = Bot
        fields = ('id', 'created_at', 'modified_at', 'creator', 'name', 'price', 'thumbnail', 'biography')


class PublicBotSerializer(serializers.ModelSerializer):
    creator = MinimalUserSerializer(read_only=True)

    class Meta:
        model = Bot
        fields = ('id', 'created_at', 'modified_at', 'name', 'price', 'thumbnail', 'biography', 'creator')

    def to_representation(self, instance):
        data = super().to_representation(instance)
        request = self.context.get('request', None)
        if request.user and request.user.is_authenticated:
            user = request.user
            active_subscription = Subscription.objects.filter(subscriber=user, status=Subscription.Status.ACTIVE, service__bot=instance).last()
            data['created'] = user == instance.creator
            data['subscribed'] = (user != instance.creator) and active_subscription is not None
            data['cancellation_scheduled'] = active_subscription is not None and active_subscription.is_cancellation_scheduled 
        return data


class SubscribedBotSerializer(serializers.ModelSerializer):
    creator = MinimalUserSerializer(read_only=True)
    token = BotTokenMinimalSerializer(read_only=True)
    
    class Meta:
        model = Bot
        fields = ('id', 'created_at', 'modified_at', 'name', 'price', 'thumbnail', 'biography', 'creator', 'token')

class BotRankSerializer(serializers.ModelSerializer):
    usage = serializers.IntegerField(source='token.usage')

    class Meta:
        model = Bot
        fields = ['id', 'name', 'thumbnail', 'usage']


class BotStartPaymentSessionSerializer(StartPaymentSessionSerializer):
    ...


class BotCompletePaymentSessionSerializer(CompletePaymentSessionSerializer):
    ...


class BotTrainingCostSerializer(serializers.Serializer):
    cost = serializers.FloatField()


class BotVisibilitySerializer(serializers.Serializer):
    visibility = serializers.ChoiceField(Bot.Visibility.choices)


class BotSubscriptionCancelSerializer(serializers.Serializer):
    reason = serializers.CharField(allow_null=True, allow_blank=True)

class BotAIPSIdSerializer(serializers.Serializer):
    id = serializers.UUIDField()