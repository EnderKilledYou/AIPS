import time
from datetime import datetime
from celery import shared_task
from django.utils import timezone
from datetime import timedelta
from django.conf import settings
from api.Subscription.models import Subscription, Service
from api.Payment.models import PaymentHistory
from api.Token.models import CreatorToken, CreatorTokenHistory
from api.Wallet.models import Wallet, WalletHistory

from services.payment import payment_service


@shared_task()
def greeting_every_minute(*args, **kwargs):
    print(f"greeting_every_minute: {kwargs}")
    time.sleep(5)
    print(f"Bye!")

    return {'timestamp': f"{datetime.now()}"}


@shared_task()
def subscription_renewal_task():
    now = timezone.now()
    subscriptions = Subscription.objects.filter(status=Subscription.Status.ACTIVE)
    for subscription in subscriptions:
        renewal_offset = subscription.service.get_renewal_offset()
        bot = subscription.service.bot

        if subscription.next_extend_at <= now:
            if subscription.is_cancellation_scheduled:
                subscription.status = Subscription.Status.CANCELED
                subscription.save()
                continue

            amount = subscription.service.price
            if amount > 0:
                payment_method = subscription.subscriber.payment_methods.last()

                # TODO: payment failure handling
                payment_service.instant_charge(
                    amount,
                    payment_method.stripe_customer_id,
                    payment_method.stripe_payment_method_id
                )

                PaymentHistory.objects.create(
                    payer_email=subscription.subscriber.email,
                    amount=amount,
                    payment_method=subscription.payment_method,
                    description=f"Subscription renewal: {bot.name}"
                )

                if subscription.service.name == Service.ServiceName.BOT_SUBSCRIPTION:
                    tokens_credited = round((amount * 20 / 100), 2) * 10000
                    creator_token = CreatorToken.objects.get(user=bot.creator)
                    creator_token.balance += tokens_credited
                    creator_token.save()

                    CreatorTokenHistory.objects.create(
                        amount=tokens_credited,
                        reason=f"Credit for subscription renewal from {subscription.subscriber.username}",
                        token=creator_token
                    )

                    # Add 80% to creator's wallet balance
                    wallet_credit_amount = round((amount * 80 / 100), 2)
                    wallet = Wallet.objects.get(owner=bot.creator)
                    wallet.balance += wallet_credit_amount
                    wallet.save()

                    WalletHistory.objects.create(
                        amount=wallet_credit_amount,
                        description=f"Credit for subscription renewal from {subscription.subscriber.username}",
                        wallet=wallet
                    )

                    PaymentHistory.objects.create(
                        payer_email=subscription.subscriber.email,
                        amount=amount,
                        payment_method=subscription.payment_method,
                        description=f"Subscription renewal: {bot.name}"
                    )
                else:
                    # Credit creator token
                    tokens_credited = subscription.price * 10000
                    creator_token = CreatorToken.objects.get(user=subscription.subscriber)
                    creator_token.balance += tokens_credited
                    creator_token.save()

                    CreatorTokenHistory.objects.create(
                        amount=tokens_credited,
                        reason="Credit",
                        token=creator_token
                    )

            subscription.price = amount
            subscription.last_payment_at = timezone.now()
            subscription.last_extend_at = timezone.now()
            subscription.next_extend_at = timezone.now() + subscription.service.get_renewal_offset()
            subscription.save()
