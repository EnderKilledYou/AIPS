from django.contrib import admin
from ..base.admin import BaseAdmin
from .models import Upload


@admin.register(Upload)
class UploadAdmin(BaseAdmin):
    model = Upload
