import uuid
import requests
from django.conf import settings
from celery_tasks.train_bot import train_bot


class BotService:
    def __init__(self, bot):
        self.bot = bot
        self.base_url = settings.BOT_API_HOST
        self.session = requests.session()

        self.session.headers = {
            "Content-Type": "application/json"
        }

    def train(self):
        train_bot.delay(self.bot.id)

    def messageWithAIPS(self, prompt_text, language='en'):
        url = f'{self.base_url}/{self.bot.path}'
        data = {
            'text': prompt_text,
            'language': language,
            'bot_name': self.bot.name
        }

        response = self.session.post(url, json=data)
        if response.status_code == 200:
            jsonData = response.json()
            return jsonData
        else:
            return {
                'response': "I'm sorry, please try again later.",
                'status_code': response.status_code,
                'raw_text': response.text
            }
        
    def message(self, prompt_text, recall, language='en'):
        user_id = uuid.UUID(int=self.bot.creator.id)
        llm = self.bot.engine.llm
        if not llm:
            llm = "gpt-4o"

        anchor = "Bot only answers questions based on the training materials provided." if self.bot.restrict_response else "Bot answers based primarily on training materials, but also supplements its prior knowledge."

        url = f'{settings.DATALOADER_API_HOST}/customevents'
        data = {
            "bucket_name": settings.AWS_TRAINING_BUCKET,
            "directory": f"{user_id}/",
            "bot_ID": str(self.bot.id),
            "prompt": self.bot.anchor_prompt,
            "text": prompt_text,
            "user": self.bot.creator.username,
            "language": language,
            "llm": llm,
            "recall": recall,
            "anchor": anchor
        }

        response = self.session.post(url, json=data)
        if response.status_code == 200:
            jsonData = response.json()
            jsonData['usage'] = jsonData['output_tokens']
            return jsonData
        else:
            return {
                'response': "I'm sorry, please try again later.",
                'status_code': response.status_code,
                'raw_text': response.text,
                'usage': 0
            }
