import json
import time
from datetime import datetime
from celery import shared_task
from celery.utils.log import get_task_logger
from celery.result import AsyncResult

from django.conf import settings
from core.celery import celery_middleware, celery_dataloader

logger = get_task_logger(__name__)


@shared_task()
def start_task(bot_id, user_id):
    print(f"Start task: \t bot_id:{bot_id}, user_id:{user_id}")
    time.sleep(5)
    return {'task': 'hello_task', 'completed': True}


@shared_task()
def process_task(task_id):
    print(task_id)

    result = AsyncResult(task_id, app=celery_middleware)
    print(result.ready())
    while not result.ready():
        time.sleep(1)
        result = AsyncResult(task_id, app=celery_middleware)
        print(result.ready())

    return result.result


@shared_task()
def start_train(bot_id, user_id):
    print(f"Start train: \t bot_id:{bot_id}, user_id:{user_id}")
    time.sleep(5)

    start_train_task = celery_dataloader.signature('app.start_train')
    result = start_train_task.apply_async(
        args=[
            settings.AWS_TRAINING_BUCKET,                   # training bucket name
            '00000000-0000-0000-0000-000000000001/',        # user id
            [],                                             # url list
            '0c781a19-c83b-4066-9629-de4828a1f4fc'          # bot id
        ]
    )

    result = AsyncResult(result.id, app=celery_dataloader)
    print(result.ready())

    while not result.ready():
        time.sleep(1)
        result = AsyncResult(result.id, app=celery_dataloader)
        print(result.ready())

    print(result.ready())
    print(result.result)

    # TODO: make bot training => active



