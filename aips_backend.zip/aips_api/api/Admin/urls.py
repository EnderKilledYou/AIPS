from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import PricingUpdateView

router = DefaultRouter()

urlpatterns = router.urls + [
    path('xyz/pricing', PricingUpdateView.as_view(), name="xyz-pricing"),
]
