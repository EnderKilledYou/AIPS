from django.apps import AppConfig


class CeleryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'celery_tasks'
    label = 'celery_tasks'

    def ready(self):
        from celery_tasks import general_task
        from celery_tasks import scheduler_task
        from celery_tasks import train_bot
        return super().ready()