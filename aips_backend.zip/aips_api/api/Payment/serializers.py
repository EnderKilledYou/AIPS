from rest_framework import serializers
from .models import PaymentMethod, PaymentHistory, PaymentSession


class PaymentMethodSerializer(serializers.ModelSerializer):

    class Meta:
        model = PaymentMethod
        exclude = ('is_deleted',)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data


class PaymentHistorySerializer(serializers.ModelSerializer):

    class Meta:
        model = PaymentHistory
        exclude = ('is_deleted',)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data


class StartPaymentSessionSerializer(serializers.Serializer):
    session_id = serializers.UUIDField(read_only=True)
    stripe_client_secret = serializers.CharField(read_only=True)
    type = serializers.ChoiceField(choices=PaymentSession.Type.choices, write_only=True)


class CompletePaymentSessionSerializer(serializers.Serializer):
    session_id = serializers.UUIDField(write_only=True)
    amount_paid = serializers.IntegerField(read_only=True)
