from rest_framework import serializers


class PricingSerializer(serializers.Serializer):
    bot_creation = serializers.FloatField(min_value=0.1, max_value=1000)
    bot_publish = serializers.FloatField(min_value=0.1, max_value=1000)
    token_purchase = serializers.FloatField(min_value=0.000001, max_value=0.1)
    bot_subscription_fee = serializers.FloatField(min_value=1, max_value=50)
