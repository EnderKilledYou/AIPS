from rest_framework.routers import DefaultRouter
from .views import ServiceViewSet, SubscriptionViewSet


router = DefaultRouter()
# router.register(r'subscription/services', ServiceViewSet, basename='subscription-services')
# router.register(r'subscription/subscriptions', SubscriptionViewSet, basename='subscription-subscriptions')
urlpatterns = router.urls
