from rest_framework import serializers


class BaseModelSerializer(serializers.ModelSerializer):
    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data


class BaseMeta:
    fields = '__all__'
    read_only_fields = ['is_deleted']
