from drf_spectacular.utils import extend_schema
from rest_framework.viewsets import ModelViewSet
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication

from .models import (
    Upload
)

from .serializers import (
    UploadSerializer
)


@extend_schema(
        tags=["Upload"]
    )
class UploadViewSet(ModelViewSet):
    queryset = Upload.objects.all()
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    serializer_class = UploadSerializer
    http_method_names = ['post',]
