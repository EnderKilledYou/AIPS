#!/bin/bash

echo "Deployment start."

PROJECT_HOME=/home/ubuntu/aips_api

mkdir -p ${PROJECT_HOME}/logs

echo "Install requirements..."
. ${PROJECT_HOME}/venv/bin/activate

pip install -r ${PROJECT_HOME}/requirements.txt

echo "Migrate models..."
${PROJECT_HOME}/venv/bin/python ${PROJECT_HOME}/manage.py migrate

echo "Seed data..."
${PROJECT_HOME}/venv/bin/python ${PROJECT_HOME}/manage.py seed

echo "Service reload..."
sudo service aips-api restart

echo "Celery reload..."
sudo supervisorctl reload

echo "Nginx reload..."
sudo service nginx restart

echo "Cleaning up..."
rm -rf ${PROJECT_HOME}/.git
rm -rf ${PROJECT_HOME}/.github

echo "Deployment end."

