from django.core.management.base import BaseCommand
from django.utils import timezone
from api.Auth.models import AuthUser


class Command(BaseCommand):
    help = """
        command: create_admin 
        description: Create admin or update to admin
        usage: python manage.py create_admin --email aips@aips.com --password Letmein123!
    """

    def add_arguments(self, parser):
        parser.add_argument('--email', type=str, help='Email address')
        parser.add_argument('--password', type=str, help='Superuser password')

    def handle(self, *args, **kwargs):
        email = kwargs.get('email', 'aips@aips.com')
        password = kwargs.get('password', 'Letmein123!')

        print(email, password)

        try:
            user = AuthUser.objects.get(email=email)
            user.is_staff = True
            user.is_superuser = True
            user.set_password(password)
            user.save()
        except AuthUser.DoesNotExist:
            AuthUser.objects.create_superuser(
                email=email,
                password=password
            )
