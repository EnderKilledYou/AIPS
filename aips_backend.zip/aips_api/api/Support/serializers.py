from rest_framework import serializers
from .models import TagWall
from ..Auth.models import AuthUser

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = AuthUser
        fields = ['username', 'avatar'] 

class TagWallSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    class Meta:
        model = TagWall
        fields = ('content', 'user')

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data
    
class CreateTagWallSerializer(serializers.Serializer):
    content = serializers.CharField()