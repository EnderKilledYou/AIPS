from rest_framework import serializers
from django.contrib.auth.models import User
from .models import APISMessage, BotMessage, FeedbackMessage, FeedbackChannel

from ..Bot.serializers import BotMinimalSerializer
from ..Auth.serializers import MinimalUserSerializer


class AIPSMessageSerializer(serializers.ModelSerializer):

    class Meta:
        model = APISMessage
        exclude = ('id', 'is_deleted', 'response_json', 'created_at', 'modified_at')
        read_only_fields = ('response_text', )

        # extra_kwargs = {
        #     'prompt_text': {'write_only': True}
        # }

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'avatar']  # Adjust 'avatar' to the correct field name if different


class BotActivitySerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)  # Nested serializer to include user details

    class Meta:
        model = BotMessage
        fields = ['id', 'prompt_text', 'response_text', 'feedback', 'language', 'created_at', 'user']
        read_only_fields = ('response_text', 'created_at')


class BotMessageSerializer(serializers.ModelSerializer):
    bot_id = serializers.UUIDField(write_only=True)

    class Meta:
        model = BotMessage
        exclude = ('is_deleted', 'user', 'bot', 'response_json',)
        read_only_fields = ('response_text', )

        # extra_kwargs = {
        #     'prompt_text': {'write_only': True}
        # }

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data


class BotMessageCreateSerializer(serializers.ModelSerializer):
    bot_id = serializers.UUIDField(write_only=True)

    class Meta:
        model = BotMessage
        exclude = ('is_deleted', 'user', 'bot', 'response_json', 'feedback')
        read_only_fields = ('response_text', )

        # extra_kwargs = {
        #     'prompt_text': {'write_only': True}
        # }

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data


class BotMessageFeedbackSerializer(serializers.ModelSerializer):
    class Meta:
        model = BotMessage
        fields = ('feedback',)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data


class FeedbackChannelSerializer(serializers.ModelSerializer):
    user = MinimalUserSerializer(read_only=True)
    user_id = serializers.IntegerField(write_only=True, required=False)
    bot = BotMinimalSerializer(read_only=True)
    bot_id = serializers.UUIDField(write_only=True)

    class Meta:
        depth = 1
        model = FeedbackChannel
        exclude = ('is_deleted',)
        read_only_fields = ('name','user', 'bot', 'subscribers',)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        messages = FeedbackMessage.objects.filter(channel=instance)
        data["message_count"] = len(FeedbackMessageSerializer(messages, many=True).data)
        return data


class FeedbackChannelMinimalSerializer(serializers.ModelSerializer):

    class Meta:
        model = FeedbackChannel
        fields = ('id', 'name',)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data


class FeedbackMessageSerializer(serializers.ModelSerializer):
    sender = MinimalUserSerializer(read_only=True)
    channel = FeedbackChannelMinimalSerializer(read_only=True)

    class Meta:
        depth = 1
        model = FeedbackMessage
        exclude = ('is_deleted',)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data
