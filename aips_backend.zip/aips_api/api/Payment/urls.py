from rest_framework.routers import DefaultRouter
from .views import PaymentMethodViewSet, PaymentHistoryViewSet


router = DefaultRouter()
router.register(r'payment/methods', PaymentMethodViewSet, basename='payment-methods')
router.register(r'payment/history', PaymentHistoryViewSet, basename='payment-history')
urlpatterns = router.urls
