from rest_framework.routers import DefaultRouter
from .views import AIPSMessageViewSet, BotMessageViewSet, FeedbackMessageViewSet, FeedbackChannelViewSet


router = DefaultRouter()
router.register(r'chat/b/aips', AIPSMessageViewSet, basename='aips-bot-messages')
router.register(r'chat/b/messages', BotMessageViewSet, basename='chat-bot-messages')
router.register(r'chat/f/channels', FeedbackChannelViewSet, basename='chat-feedback-channels')
router.register(r'chat/f/messages', FeedbackMessageViewSet, basename='chat-feedback-messages')
urlpatterns = router.urls
