import time
from celery import shared_task
from api.Bot.models import Bot, TrainingMaterial
from django.conf import settings
from core.celery import celery_dataloader
from celery.result import AsyncResult
import uuid
import requests
from utils.email import send_bot_training_email
from django.utils import timezone

@shared_task()
def train_bot(bot_id, update_train = False):
    time.sleep(5)

    training_bucket = settings.AWS_TRAINING_BUCKET

    bot = Bot.objects.get(id=bot_id)
    user_id = uuid.UUID(int=bot.creator.id)

    training_materials = bot.training_materials.all()

    url_list = []
    for training_material in training_materials:
        if not training_material.url.startswith(f"https://{training_bucket}"):
            if training_material.type != TrainingMaterial.Type.CHILDURL or (training_material.type == TrainingMaterial.Type.CHILDURL and bot.include_child_page):
                url_list.append(training_material.url)

    # if settings.TRAINING_WITH_CELERY:
    #     if update_train:
    #         print(f"Bot training update started: \t {bot_id}")
    #         start_train_task = celery_dataloader.signature('app.update_train')
    #     else:
    #         print(f"Bot training started: \t {bot_id}")
    #         start_train_task = celery_dataloader.signature('app.start_train')
        
    #     if bot.engine.name == 'mixtral':
    #         model_name = 'mistral'
    #     else:
    #         model_name = 'openai'

    #     result = start_train_task.apply_async(
    #         args=[
    #             settings.AWS_TRAINING_BUCKET,
    #             f"{user_id}/",
    #             [],
    #             str(bot_id),
    #             model_name
    #         ]
    #     )

    #     result = AsyncResult(result.id, app=celery_dataloader)
    #     print("ID", result.id)
    #     print("READY", result.ready())

    #     while not result.ready():
    #         time.sleep(1)
    #         result = AsyncResult(result.id, app=celery_dataloader)
    #         print("ID", result.id)
    #         print("READY", result.ready())

    #     print("FINAL", result.ready())
    #     print("RESULT", result.result)
    # else:
    if update_train:
        print(f"Bot training update started with api: \t {bot_id}")
        api_url = f"{settings.DATALOADER_API_HOST}/updateTrain"
    else:
        print(f"Bot training started with api: \t {bot_id}")
        api_url = f"{settings.DATALOADER_API_HOST}/startTraining"

    task_res = requests.post(
        api_url, 
        json = {
            "bucket_name": settings.AWS_TRAINING_BUCKET,
            "directory": f"{user_id}/",
            "url_list": url_list,
            "bot_ID": str(bot_id)
        }
    )

    task_id = task_res.json()['task_id']
    print("Task ID: ", task_id)

    status_res = requests.post(
        f"{settings.DATALOADER_API_HOST}/check_task_status", 
        json = {
            "task_id": task_id
        }
    )
    while status_res.json()['status'] != 'success':
        time.sleep(1)
        status_res = requests.post(
            f"{settings.DATALOADER_API_HOST}/check_task_status", 
            json = {
                "task_id": task_id
            }
        )

    print("Result: ", status_res.json())

    bot.status = Bot.Status.ACTIVE
    bot.save()

    current_date = timezone.now()
    formatted_date = current_date.strftime('%m/%d/%Y')

    send_bot_training_email(bot.creator.email, bot, formatted_date, update_train)