mkdir -p celery/
celery -A core beat --loglevel=INFO -s ./celery/celerybeat-schedule.db
