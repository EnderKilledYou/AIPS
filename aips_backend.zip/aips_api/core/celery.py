import os
import json

from pathlib import Path
from celery import Celery
from django.conf import settings

from datetime import timedelta
from celery.schedules import crontab

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')
Path(f"{settings.BASE_DIR}/logs/celery").mkdir(parents=True, exist_ok=True)

celery_middleware = Celery('middleware')
celery_middleware.config_from_object('django.conf:settings', namespace='CELERY')
celery_middleware.autodiscover_tasks(lambda: settings.INSTALLED_APPS)

celery_dataloader = Celery(
    'dataloader',
    broker=settings.DATALOADER_BROKER_URL,
    backend=settings.DATALOADER_RESULT_BACKEND,
)

# scheduler -> celery.beat.PersistentScheduler

celery_middleware.conf.beat_schedule = {
    # Executes every minute
    'execute_every_minute': {
        'task': 'celery_tasks.scheduler_task.greeting_every_minute',
        'schedule': 60.0,
        'kwargs': {
            'schedule': '1 minute',
        },
    },

    # # Executes every hour
    # 'execute_every_hour': {
    #     'task': 'celery_tasks.hello_task.hello_task',
    #     'schedule': crontab(hour=1),
    #     'kwargs': {
    #         'schedule': '1 hour',
    #     },
    # },
}
