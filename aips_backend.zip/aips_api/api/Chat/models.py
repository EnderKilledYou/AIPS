from django.db import models
from ..base.model import BaseModel
from ..Auth.models import AuthUser
from ..Bot.models import Bot


class APISMessage(BaseModel):
    class Language(models.TextChoices):
        ENGLISH = 'en'
        SPANISH = 'es'
        RUSSIAN = 'ru'
        FRENCH = 'fr'

    prompt_text = models.TextField()
    response_text = models.TextField(null=True, blank=True)
    response_json = models.JSONField(default=dict)
    language = models.CharField(max_length=32, choices=Language.choices, default=Language.ENGLISH)

    def __str__(self):
        return f"{self.prompt_text}"


class BotMessage(BaseModel):
    class Feedback(models.TextChoices):
        UNKNOWN = 'unknown'
        UP = 'up'
        DOWN = 'down'

    class Language(models.TextChoices):
        ENGLISH = 'en'
        SPANISH = 'es'
        RUSSIAN = 'ru'
        FRENCH = 'fr'

    prompt_text = models.TextField()
    response_text = models.TextField(null=True, blank=True)
    response_json = models.JSONField(default=dict)
    feedback = models.CharField(max_length=32, choices=Feedback.choices, blank=True, null=True)
    language = models.CharField(max_length=32, choices=Language.choices, default=Language.ENGLISH)
    bot = models.ForeignKey(Bot, related_name='bot_messages', on_delete=models.CASCADE)
    user = models.ForeignKey(AuthUser, related_name='bot_messages', on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.prompt_text}"


class FeedbackChannel(BaseModel):
    name = models.CharField(max_length=256)
    user = models.ForeignKey(AuthUser, related_name='feedback_channels', on_delete=models.CASCADE)
    subscribers = models.JSONField(default=dict)
    bot = models.ForeignKey(Bot, related_name='feedback_channels', on_delete=models.CASCADE)
    last_message = models.OneToOneField('FeedbackMessage', related_name='last_message_in_channel',
                                        on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.name


class FeedbackMessage(BaseModel):
    message = models.TextField()
    sender = models.ForeignKey(AuthUser, related_name='feedback_messages', on_delete=models.CASCADE)
    channel = models.ForeignKey(FeedbackChannel, related_name='messages', on_delete=models.CASCADE, null=True)

    class Meta:
        ordering = ['created_at']

    def __str__(self):
        return f"{self.message}"
