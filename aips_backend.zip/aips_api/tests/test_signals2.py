import unittest
from unittest.mock import patch, MagicMock
from django.contrib.auth.models import User as AuthUser
from django.test import TestCase
from django.db.models.signals import post_save
from api.Wallet.signals import post_save_user
from api.Wallet.models import Wallet

class PostSaveUserSignalReceiverTest(TestCase):

    @patch('api.Wallet.models.Wallet.objects.create')
    @patch('api.Wallet.models.Wallet.objects.get')
    def test_post_save_user_when_wallet_exists(self, mock_get, mock_create):
        user = AuthUser.objects.create_user(username='testuser', password='testpassword')
        mock_get.return_value = Wallet(owner=user)
        
        post_save_user(AuthUser, user)

        mock_get.assert_called_once_with(owner=user)
        mock_create.assert_not_called()

    @patch('api.Wallet.models.Wallet.objects.create')
    @patch('api.Wallet.models.Wallet.objects.get')
    def test_post_save_user_when_wallet_does_not_exist(self, mock_get, mock_create):
        user = AuthUser.objects.create_user(username='testuser', password='testpassword')
        error = Wallet.DoesNotExist()
        mock_get.side_effect = error

        post_save_user(AuthUser, user)

        mock_get.assert_called_once_with(owner=user)
        mock_create.assert_called_once_with(owner=user)