from django.contrib import admin
from ..base.admin import BaseAdmin
from .models import APISMessage, BotMessage, FeedbackMessage, FeedbackChannel


@admin.register(APISMessage)
class APISMessageAdmin(BaseAdmin):
    model = APISMessage


@admin.register(BotMessage)
class BotMessageAdmin(BaseAdmin):
    model = BotMessage


@admin.register(FeedbackChannel)
class FeedbackChannelAdmin(BaseAdmin):
    model = FeedbackChannel


@admin.register(FeedbackMessage)
class FeedbackMessageAdmin(BaseAdmin):
    model = FeedbackMessage
