from django.urls import path
from django.conf.urls import include
from api.Auth.views import (
    TokenRegisterViewSet,
    TokenLoginViewSet,
    TokenVerifyViewSet,
    TokenResendViewSet,
    LogoutView,
    RefreshView,
    BasicLoginView,
    BasicRegisterViewSet,
    ProfileViewSet,
    UserViewSet,
    RegisterConfirmViewSet,
    PasswordResetViewSet,
    PasswordConfirmViewSet,
    PasswordUpdateViewSet,
    EmailUpdateViewSet,
    UsernameUpdateViewset
)

urlpatterns = [
    path("auth/register/", TokenRegisterViewSet.as_view({'post': 'create'}), name="register"),
    path("auth/login/", TokenLoginViewSet.as_view({'post': 'create'}), name="login"),
    path("auth/verify/", TokenVerifyViewSet.as_view({'post': 'create'}), name="verify"),
    path("auth/resend/", TokenResendViewSet.as_view({'post': 'create'}), name="resend"),
    path("auth/refresh/", RefreshView.as_view(), name="refresh"),
    path("auth/logout/", LogoutView.as_view(), name="logout"),
]


# urlpatterns += [
#     path("auth/register/", BasicRegisterViewSet.as_view({'post': 'create'}), name="register"),
#     path("auth/login/", BasicLoginView.as_view(), name="login"),
#     path("auth/register/confirm/", RegisterConfirmViewSet.as_view(
#         {
#             'post': 'activation',
#         }
#     ), name="register-confirm"),
#
#     path("auth/reset/password/", PasswordResetViewSet.as_view(
#         {
#             'post': 'reset_password',
#         }
#     ), name="reset-password"),
#     path("auth/reset/password/confirm/", PasswordConfirmViewSet.as_view(
#         {
#             'post': 'reset_password_confirm',
#         }
#     ), name="reset-password-confirm"),
# ]

# Users
# urlpatterns += [
#     path("users/", UserViewSet.as_view(
#         {
#             'get': 'list',
#         }
#     ), name="users"),
#     path("users/<int:id>", UserViewSet.as_view(
#         {
#             'get': 'retrieve',
#             'put': 'update',
#             'patch': 'partial_update',
#             'delete': 'destroy'
#         }
#     ), name="user-details"),
# ]

# Profile
urlpatterns += [
    path("profile/", ProfileViewSet.as_view(
        {
            'get': 'me',
            'put': 'me',
            'patch': 'me',
            'delete': 'me'
        }
    ), name="profile"),
    path("profile/update/username/", UsernameUpdateViewset.as_view(
        {
            'put': 'set_username',
        }
    ), name="profile-username-update"),
    path("profile/update/email/", EmailUpdateViewSet.as_view(
        {
            'post': 'set_username',
        }
    ), name="profile-email-update"),
    # path("profile/update/password/", PasswordUpdateViewSet.as_view(
    #     {
    #         'post': 'set_password',
    #     }
    # ), name="profile-password-update"),
]
