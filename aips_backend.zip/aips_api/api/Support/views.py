from drf_spectacular.utils import extend_schema
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAuthenticated
from ..base.permissions import IsSupportUser
from rest_framework.response import Response
from rest_framework import status
from ..Bot.models import Bot
from ..Bot.serializers import BotMinimalSerializer, BotRankSerializer
from ..Auth.models import AuthUser
from ..Auth.serializers import SupportUserSerializer, RankUserSerializer
from .models import TagWall
from django.db.models import Count
from .serializers import TagWallSerializer, CreateTagWallSerializer
from django.utils import timezone
from datetime import timedelta

@extend_schema(
    tags=["Support"]
)
class SupportResultView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated, IsSupportUser]

    def get(self, request):
        param = self.request.query_params
        search = param.get("search", "")

        if not search:
            return Response({
                "bots": [],
                "users": []
            }, status=status.HTTP_200_OK)
        
        bots = Bot.objects.filter(name__icontains = search, visibility = Bot.Visibility.PUBLIC, status = Bot.Status.ACTIVE)
        users = AuthUser.objects.filter(username__icontains = search, role = AuthUser.Role.USER)

        return Response({
            "users": SupportUserSerializer(users, many=True).data,
            "bots": BotMinimalSerializer(bots, many=True).data
        }, status=status.HTTP_200_OK)
    
@extend_schema(
    tags=["Support"]
)
class UserRankSet(APIView):

    def get(self, request):
        users = AuthUser.objects.annotate(message_count=Count('bot_messages')).order_by('-message_count')[:10]
        return Response({
            "users": RankUserSerializer(users, many=True).data
        }, status=status.HTTP_200_OK)
    
@extend_schema(
    tags=["Support"]
)
class BotRankSet(APIView):

    def get(self, request):
        bots = Bot.objects.all().select_related('token').order_by('-token__usage')[:10]
        return Response({
            "bots": BotRankSerializer(bots, many=True).data
        }, status=status.HTTP_200_OK)
    

@extend_schema(
    tags=["Support"]
)
class TagWallSet(APIView):
    authentication_classes = [JWTAuthentication]

    def get_permissions(self):
        if self.request.method == 'GET':
            return []
        elif self.request.method == 'POST':
            return [IsAuthenticated()]
        return super().get_permissions()
    
    def get(self, request):
        histories = TagWall.objects.all().order_by('-created_at')
        
        return Response({
            "histories": TagWallSerializer(histories, many=True).data
        }, status=status.HTTP_200_OK)
    
    def post(self, request, *args, **kwargs):
        user = self.request.user

        serializer = CreateTagWallSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        one_year_ago = timezone.now() - timedelta(days=365)
        tagwall = TagWall.objects.filter(created_at__gte=one_year_ago, user = user).order_by('-created_at').first()
        if tagwall is None:
            TagWall.objects.create(content = data["content"], user=user)
        else:
            return Response(
                {'message': "You can post every 12 months"},
                status=status.HTTP_400_BAD_REQUEST
            )

        return Response({
            "message": 'success'
        }, status=status.HTTP_200_OK)