from unittest import TestCase


class Test(TestCase):
    def test_post_save_user(self):
        user = AuthUser.objects.create_user(username='testuser', password='testpassword')


        post_save_user(AuthUser, user)

        self.fail()
