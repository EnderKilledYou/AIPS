def add_numbers(x,y):
    return x+y

def test_add_numbers():
    result = add_numbers(3, 4)
    assert result == 7
