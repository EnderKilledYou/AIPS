from django.utils import timezone
from django.db.models import Q
from drf_spectacular.utils import extend_schema
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import status
from rest_framework.viewsets import ModelViewSet
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework import filters

from .models import Bot, Engine, TrainingMaterial
from ..Subscription.models import Price, Service, Subscription
from ..Payment.models import PaymentSession, PaymentMethod, PaymentHistory
from ..Token.models import CreatorToken, CreatorTokenHistory
from ..Wallet.models import Wallet, WalletHistory
from utils.email import send_new_bot_email,send_new_subscription_email

from .serializers import (
    BotSerializer,
    EngineSerializer,
    TrainingMaterialSerializer,
    BotTrainingCostSerializer,
    BotStartPaymentSessionSerializer,
    BotCompletePaymentSessionSerializer,
    BotVisibilitySerializer,
    BotSubscriptionCancelSerializer,
    PublicBotSerializer,
    SubscribedBotSerializer,
    BotAIPSIdSerializer,
    TrainingMaterialSublinkSerializer
)

from services.training import training_service
from services.payment import payment_service

from celery_tasks.train_bot import train_bot
from celery_tasks.general_task import start_task, process_task, start_train


@extend_schema(
    tags=["Bot"]
)
class BotViewSet(ModelViewSet):
    queryset = Bot.objects.all()
    serializer_class = BotSerializer
    authentication_classes = [JWTAuthentication]
    http_method_names = ['get', 'post', 'put', 'patch']

    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['name', ]
    ordering_fields = ['price', 'created_at', 'modified_at']

    def get_permissions(self):
        if self.action == 'public':
            self.permission_classes = []
        else:
            self.permission_classes = [IsAuthenticated]

        return super(self.__class__, self).get_permissions()

    def get_queryset(self):
        param = self.request.query_params

        if self.action == 'public':
            queryset = Bot.objects.filter(
                visibility=Bot.Visibility.PUBLIC,
                status=Bot.Status.ACTIVE
            )
        elif self.action == 'subscribed':
            queryset = Bot.objects.filter(
                ~Q(creator=self.request.user),
                status=Bot.Status.ACTIVE,
                services__subscriptions__subscriber=self.request.user,
                services__subscriptions__status=Subscription.Status.ACTIVE,
                services__subscriptions__is_cancellation_scheduled=False
            ).order_by('id', '-created_at').distinct('id')
        elif self.action == 'created':
            queryset = Bot.objects.filter(
                creator=self.request.user
            ).exclude(status = Bot.Status.DISABLED)
        else:
            queryset = Bot.objects.all()

        if param:
            date_from = param.get("date_from", "")
            date_to = param.get("date_to", "")
            price_from = param.get("price_from", "")
            price_to = param.get("price_to", "")

            if date_from:
                queryset = queryset.filter(created_at__gte=date_from)
            if date_to:
                queryset = queryset.filter(created_at__lte=date_to)

            if price_from:
                queryset = queryset.filter(price__gte=price_from)
            if price_to:
                queryset = queryset.filter(price__lte=price_to)

        return queryset.exclude(name="AIPS")
    
    def update(self, request, *args, **kwargs):
        bot = self.get_object()
        
        update_train = request.query_params.get("update_train", "")
        if update_train:
            train_bot.delay(bot.id, True)
        
        return super().update(request, *args, **kwargs)

    # def list(self, request, *args, **kwargs):
    #     return Response({"message": "Not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    @extend_schema(
        tags=["Bot", "Public"]
    )
    @action(
        methods=["get"],
        detail=False,
        url_path="public",
        url_name="public",
        serializer_class=PublicBotSerializer
    )
    def public(self, request, *args, **kwargs):
        """ Internal celery task processing """
        # task = start_task.delay('bot_id', 'user_id')
        # process_task.delay(task.id)

        """ External task processing """
        # task = start_train.delay('bot_id', 'user_id')
        # print(task.id)

        # train_bot.delay('4bbac229-2243-4865-a7fa-24bf50cb1c4b')

        return super().list(request, args, kwargs)

    @action(methods=["patch"], detail=False, url_path="delete-bot")
    def delete_bot(self, request, *args, **kwargs):
        bot_id = request.query_params.get('bot_id')
        try:
            bot = Bot.objects.get(id=bot_id)
        except Bot.DoesNotExist:
            return Response({'detail': 'Bot not found.'}, status=status.HTTP_404_NOT_FOUND)

        subscriptions = Subscription.objects.filter(service__bot=bot)
        for subscription in subscriptions:
            subscription.status = Subscription.Status.SUSPENDED
            subscription.save()

        bot.status = "disabled"
        bot.save()
        
        return Response("Bot deleted successfully.", status=status.HTTP_204_NO_CONTENT)

    @extend_schema(
        tags=["Bot", "User"]
    )
    @action(
        methods=["get"],
        detail=False,
        url_path="subscribed",
        url_name="subscribed",
        serializer_class=SubscribedBotSerializer
    )
    def subscribed(self, request, *args, **kwargs):
        return super().list(request, args, kwargs)

    @extend_schema(
        tags=["Bot"]
    )
    @action(
        methods=["get"],
        detail=False,
        url_path="aips",
        url_name="aips",
        serializer_class=BotAIPSIdSerializer
    )
    def aips_id(self, request, *args, **kwargs):
        bot = Bot.objects.get(name='AIPS')
        
        return Response(
            {'id': bot.id},
            status=status.HTTP_200_OK
        )
    
    @extend_schema(
        tags=["Bot", "Creator"]
    )
    @action(
        methods=["get"],
        detail=False,
        url_path="created",
        url_name="created",
    )
    def created(self, request, *args, **kwargs):
        return super().list(request, args, kwargs)

    @extend_schema(
        tags=["Bot", "User"]
    )
    @action(
        methods=["post"],
        detail=True, url_path="start-subscription",
        url_name="start-subscription",
        serializer_class=BotStartPaymentSessionSerializer
    )
    def start_subscription(self, request, *args, **kwargs):
        bot = self.get_object()
        user = request.user
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)

        if serializer.validated_data['type'] != PaymentSession.Type.BOT_SUBSCRIPTION:
            return Response(
                {'message': "Operation not allowed"},
                status=status.HTTP_400_BAD_REQUEST
            )

        if bot.status != Bot.Status.ACTIVE or bot.visibility == Bot.Visibility.PRIVATE:
            return Response(
                {'message': "Bot is not available to subscribe"},
                status=status.HTTP_400_BAD_REQUEST
            )

        bot_subscription_service = Service.objects.get(
            name=Service.ServiceName.BOT_SUBSCRIPTION,
            bot=bot
        )

        try:
            bot_subscription_subscription = Subscription.objects.get(
                service=bot_subscription_service,
                subscriber=user
            )

            if bot_subscription_subscription.status == Subscription.Status.ACTIVE:
                if bot_subscription_subscription.is_cancellation_scheduled == True:
                    bot_subscription_subscription.is_cancellation_scheduled = False
                    bot_subscription_subscription.save()
                    return Response(
                        {'message': f"Subscribed: {bot.name}"},
                        status=status.HTTP_200_OK
                    )           
                else:
                    return Response(
                        {'message': "User has active subscription"},
                        status=status.HTTP_409_CONFLICT
                    )
        except Subscription.DoesNotExist:
            bot_subscription_subscription = Subscription.objects.create(
                price=bot_subscription_service.price,
                status=Subscription.Status.PENDING,
                service=bot_subscription_service,
                subscriber=user,
            )

        total_cost = bot_subscription_service.price
        if total_cost > 0:
            payment_data = {
                'email': user.email,
                'amount': total_cost,
                'source': 'Bot subscription flow'
            }
            session = payment_service.create_payment_session(payment_data)

            payment_session = PaymentSession.objects.create(
                amount=total_cost,
                status=PaymentSession.Status.PENDING,
                type=PaymentSession.Type.BOT_CREATION,
                stripe_payment_intent_id=session.id,
                stripe_customer_id=session.customer,
                stripe_client_secret=session.client_secret,
                user=user
            )

            return Response({
                'session_id': payment_session.id,
                'stripe_client_secret': session.client_secret
            }, status=status.HTTP_200_OK)
        else:
            # Activate free bot subscription instantly
            bot_subscription_subscription.status = Subscription.Status.ACTIVE
            bot_subscription_subscription.last_payment_at = timezone.now()
            bot_subscription_subscription.save()

            return Response(
                {'message': f"Subscribed: {bot.name}"},
                status=status.HTTP_200_OK
            )

    @extend_schema(
        tags=["Bot", "User"]
    )
    @action(
        methods=["post"],
        detail=True,
        url_path="complete-subscription",
        url_name="complete-subscription",
        serializer_class=BotCompletePaymentSessionSerializer
    )
    def complete_subscription(self, request, *args, **kwargs):
        bot = self.get_object()
        user = request.user
        creator = bot.creator
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)

        payment_session = PaymentSession.objects.get(
            id=serializer.validated_data['session_id']
        )
        if payment_session.status == PaymentSession.Status.SUCCESS:
            return Response(
                {'message': "Payment already processed"},
                status=status.HTTP_400_BAD_REQUEST
            )

        success = payment_service.verify_payment_status(
            payment_session.stripe_payment_intent_id,
            payment_session.amount
        )

        if not success:
            return Response(
                {'message': "Unable to verify your payment"},
                status=status.HTTP_400_BAD_REQUEST
            )

        completed_session = payment_service.complete_payment_session(
            payment_session.stripe_payment_intent_id
        )

        try:
            payment_method = PaymentMethod.objects.get(
                stripe_customer_id=completed_session['customer_id'],
                stripe_payment_method_id=completed_session['payment_method_id'],
                owner=user
            )
        except PaymentMethod.DoesNotExist:
            payment_method = PaymentMethod.objects.create(
                type=PaymentMethod.Type.CARD,
                email=user.email,
                stripe_customer_id=completed_session['customer_id'],
                stripe_payment_method_id=completed_session['payment_method_id'],
                last4_digits=completed_session['last4_digits'],
                owner=user
            )

        # Activate pending subscriptions: Bot creation, Bot publish, Bot training
        creation_subscription = Subscription.objects.get(
            service__name=Service.ServiceName.BOT_SUBSCRIPTION,
            service__bot=bot,
            subscriber=user
        )
        creation_subscription.status = Subscription.Status.ACTIVE
        creation_subscription.payment_method = payment_method
        creation_subscription.last_payment_at = timezone.now()
        creation_subscription.save()

        # Create payment history
        PaymentHistory.objects.create(
            payer_email=user.email,
            amount=payment_session.amount,
            payment_method=payment_method,
            description=f"Bot subscription: ${bot.name}"
        )

        # Credit creator token for 20% of payment
        tokens_credited = round((payment_session.amount * 20 / 100), 2) * 10000
        creator_token = CreatorToken.objects.get(user=creator)
        creator_token.balance += tokens_credited
        creator_token.save()

        CreatorTokenHistory.objects.create(
            amount=tokens_credited,
            reason=f"Credit for subscription payment from {user.username}",
            token=creator_token
        )

        # Add 80% to creator's wallet balance
        wallet_credit_amount = round((payment_session.amount * 80 / 100), 2)
        wallet = Wallet.objects.get(owner=creator)
        wallet.balance += wallet_credit_amount
        wallet.save()

        WalletHistory.objects.create(
            amount=wallet_credit_amount,
            description=f"Credit for subscription payment from {user.username}",
            wallet=wallet
        )

        payment_session.status = PaymentSession.Status.SUCCESS
        payment_session.save()

        send_new_subscription_email(bot.creator.email,bot,user.username)

        return Response(
            {
                'message': "Payment confirmed",
                'amount_paid': payment_session.amount
            },
            status=status.HTTP_200_OK
        )

    @extend_schema(
        tags=["Bot", "User"]
    )
    @action(
        methods=["put"],
        detail=True,
        url_path="cancel-subscription",
        url_name="cancel-subscription",
        serializer_class=BotSubscriptionCancelSerializer
    )
    def cancel_subscription(self, request, *args, **kwargs):
        bot = self.get_object()
        user = request.user
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)

        try:
            active_subscription = Subscription.objects.get(
                service__name=Service.ServiceName.BOT_SUBSCRIPTION,
                status=Subscription.Status.ACTIVE,
                service__bot=bot,
                subscriber=user
            )
            if active_subscription.is_cancellation_scheduled:
                return Response(
                    {'message': "Cancellation already scheduled"},
                    status=status.HTTP_400_BAD_REQUEST
                )
        except Subscription.DoesNotExist:
            return Response(
                {'message': "No active subscription found"},
                status=status.HTTP_400_BAD_REQUEST
            )

        active_subscription.is_cancellation_scheduled = True
        active_subscription.save()

        return Response(
            {'message': "Cancellation scheduled successfully"},
            status=status.HTTP_200_OK
        )

    @extend_schema(
        tags=["Bot", "Creator"]
    )
    @action(
        methods=["get"],
        detail=True,
        url_path="training-cost",
        url_name="training-cost",
        serializer_class=BotTrainingCostSerializer
    )
    def training_cost(self, request, *args, **kwargs):
        user = request.user
        bot = self.get_object()

        update_cost = request.query_params.get("update_cost", "train")

        if user == bot.creator:
            return Response(
                {'cost': training_service.get_cost(bot, update_cost)},
                status=status.HTTP_200_OK
            )
        else:
            return Response(
                {"message": "Bot creator only"},
                status=status.HTTP_403_FORBIDDEN
            )

    @extend_schema(
        tags=["Bot", "Creator"]
    )
    @action(
        methods=["put"],
        detail=True,
        url_path="visibility",
        url_name="visibility",
        serializer_class=BotVisibilitySerializer
    )
    def visibility(self, request, *args, **kwargs):
        bot = self.get_object()
        user = request.user

        visibility = request.data['visibility']
        if visibility == bot.visibility:
            return Response(
                {'message': 'Visibility not changed'},
                status=status.HTTP_400_BAD_REQUEST
            )

        amount_paid = 0
        tokens_credited = 0
        if visibility != Bot.Visibility.PRIVATE and bot.visibility != Bot.Visibility.PRIVATE:
            # Update [invite_only, public] to [invite_only, public]
            pass
        elif visibility != Bot.Visibility.PRIVATE:
            # Update from private to [invite_only, public]
            price = Price.objects.get(name=Price.Name.BOT_PUBLISH)
            service = Service.objects.get(
                name=Service.ServiceName.BOT_PUBLISH,
                bot=bot
            )
            service.price = price.value
            service.save()

            subscription = Subscription.objects.get(
                service=service,
                subscriber=user
            )

            if subscription.price != service.price:
                amount_paid = service.price - subscription.price

                # Charge for rest of subscription cycle
                is_success = payment_service.instant_charge(
                    amount=amount_paid,
                    customer=subscription.payment_method.stripe_customer_id,
                    payment_method=subscription.payment_method.stripe_payment_method_id,
                    metadata={
                        "customer_email": user.email,
                        'source': 'Bot visibility updated'
                    }
                )

                PaymentHistory.objects.create(
                    payer_email=user.email,
                    amount=amount_paid,
                    payment_method=subscription.payment_method,
                    description=f"Bot publish: ${bot.name}"
                )

                # Credit creator token
                tokens_credited = amount_paid * 10000
                creator_token = CreatorToken.objects.get(user=user)
                creator_token.balance += tokens_credited
                creator_token.save()

                CreatorTokenHistory.objects.create(
                    amount=tokens_credited,
                    reason="Credit",
                    token=creator_token
                )

                subscription.price = service.price
                subscription.last_payment_at = timezone.now()
                subscription.last_extend_at = timezone.now()
                subscription.next_extend_at = timezone.now() + service.get_renewal_offset()
                subscription.save()
        else:
            # Update from [invite_only, public] to private
            service = Service.objects.get(
                name=Service.ServiceName.BOT_PUBLISH,
                bot=bot
            )
            service.price = 0
            service.save()

        bot.visibility = visibility
        bot.save()

        return Response(
            {
                'message': f'Visibility updated to {visibility}',
                'amount_paid': amount_paid,
                'tokens_credited': tokens_credited
            },
            status=status.HTTP_200_OK
        )

    @extend_schema(
        tags=["Bot", "Creator"]
    )
    @action(
        methods=["post"],
        detail=True,
        url_path="start-payment-session",
        url_name="start-payment-session",
        serializer_class=BotStartPaymentSessionSerializer
    )
    def start_payment_session(self, request, *args, **kwargs):
        bot = self.get_object()
        user = request.user
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)

        if serializer.validated_data['type'] != PaymentSession.Type.BOT_CREATION:
            return Response(
                {'message': "Operation not allowed"},
                status=status.HTTP_400_BAD_REQUEST
            )

        if bot.status != Bot.Status.CONFIGURE:
            return Response(
                {'message': "Operation not allowed"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Create pending subscriptions: Bot creation, Bot publish, Bot training
        bot_creation_service = Service.objects.get(
            name=Service.ServiceName.BOT_CREATION,
            bot=bot
        )
        try:
            bot_creation_subscription = Subscription.objects.get(
                service=bot_creation_service,
                subscriber=user
            )
        except Subscription.DoesNotExist:
            bot_creation_subscription = Subscription.objects.create(
                price=bot_creation_service.price,
                status=Subscription.Status.PENDING,
                service=bot_creation_service,
                subscriber=user,
            )

        bot_publish_service = Service.objects.get(
            name=Service.ServiceName.BOT_PUBLISH,
            bot=bot
        )
        try:
            bot_publish_subscription = Subscription.objects.get(
                service=bot_publish_service,
                subscriber=user
            )
        except Subscription.DoesNotExist:
            bot_publish_subscription = Subscription.objects.create(
                price=bot_publish_service.price,
                status=Subscription.Status.PENDING,
                service=bot_publish_service,
                subscriber=user,
            )

        if bot_creation_subscription.status == Subscription.Status.ACTIVE and bot_publish_subscription.status != Subscription.Status.ACTIVE:
            return Response({
                'message': "",
            }, status=status.HTTP_200_OK)

        training_cost = training_service.get_cost(bot)

        # Get total cost
        total_cost = round(bot_creation_subscription.price + bot_publish_subscription.price + training_cost, 2)

        # Generate payment session
        payment_data = {
            'email': user.email,
            'amount': total_cost,
            'source': 'Bot creation Flow'
        }
        session = payment_service.create_payment_session(payment_data)

        payment_session = PaymentSession.objects.create(
            amount=total_cost,
            status=PaymentSession.Status.PENDING,
            type=PaymentSession.Type.BOT_CREATION,
            stripe_payment_intent_id=session.id,
            stripe_customer_id=session.customer,
            stripe_client_secret=session.client_secret,
            user=user
        )

        bot.status = Bot.Status.PENDING_TRAIN
        bot.save()

        return Response({
            'session_id': payment_session.id,
            'stripe_client_secret': session.client_secret
        }, status=status.HTTP_200_OK)

    @extend_schema(
        tags=["Bot", "Creator"]
    )
    @action(
        methods=["post"],
        detail=True,
        url_path="complete-payment-session",
        url_name="complete-payment-session",
        serializer_class=BotCompletePaymentSessionSerializer
    )
    def complete_payment_session(self, request, *args, **kwargs):
        bot = self.get_object()
        user = request.user

        if bot.status != Bot.Status.PENDING_TRAIN:
            return Response(
                {'message': "Operation not allowed"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Check payment was successful
        payment_session = PaymentSession.objects.get(
            id=request.data['session_id']
        )
        if payment_session.status == PaymentSession.Status.SUCCESS:
            return Response(
                {'message': "Payment already processed"},
                status=status.HTTP_400_BAD_REQUEST
            )

        success = payment_service.verify_payment_status(
            payment_session.stripe_payment_intent_id,
            payment_session.amount
        )

        if not success:
            return Response(
                {'message': "Unable to verify your payment"},
                status=status.HTTP_400_BAD_REQUEST
            )

        completed_session = payment_service.complete_payment_session(
            payment_session.stripe_payment_intent_id
        )

        try:
            payment_method = PaymentMethod.objects.get(
                stripe_customer_id=completed_session['customer_id'],
                stripe_payment_method_id=completed_session['payment_method_id'],
                owner=user
            )
        except PaymentMethod.DoesNotExist:
            payment_method = PaymentMethod.objects.create(
                type=completed_session['type'],
                email=user.email,
                stripe_customer_id=completed_session['customer_id'],
                stripe_payment_method_id=completed_session['payment_method_id'],
                last4_digits=completed_session['last4_digits'],
                owner=user
            )

        # Activate pending subscriptions: Bot creation, Bot publish, Bot training
        creation_subscription = Subscription.objects.get(
            service__name=Service.ServiceName.BOT_CREATION,
            service__bot=bot,
            subscriber=user
        )
        creation_subscription.status = Subscription.Status.ACTIVE
        creation_subscription.payment_method = payment_method
        creation_subscription.last_payment_at = timezone.now()
        creation_subscription.last_extend_at = timezone.now()
        creation_subscription.next_extend_at = timezone.now() + creation_subscription.service.get_renewal_offset()
        creation_subscription.save()

        publish_subscription = Subscription.objects.get(
            service__name=Service.ServiceName.BOT_PUBLISH,
            service__bot=bot,
            subscriber=user
        )
        publish_subscription.status = Subscription.Status.ACTIVE
        publish_subscription.payment_method = payment_method
        publish_subscription.last_payment_at = timezone.now()
        publish_subscription.last_extend_at = timezone.now()
        publish_subscription.next_extend_at = timezone.now() + publish_subscription.service.get_renewal_offset()
        publish_subscription.save()

        train_bot.delay(bot.id)
        bot.status = Bot.Status.TRAIN
        bot.save()

        # Create payment history
        PaymentHistory.objects.create(
            payer_email=user.email,
            amount=payment_session.amount,
            payment_method=payment_method,
            description=f"Bot creation: ${bot.name}"
        )

        # Credit creator token
        tokens_credited = payment_session.amount * 10000
        creator_token = CreatorToken.objects.get(user=user)
        creator_token.balance += tokens_credited
        creator_token.save()

        CreatorTokenHistory.objects.create(
            amount=tokens_credited,
            reason="Credit",
            token=creator_token
        )

        payment_session.status = PaymentSession.Status.SUCCESS
        payment_session.save()
        training_cost= training_service.get_cost(bot)
        order_date = payment_method.modified_at.strftime("%d/%m/%Y")
        payment_method_type = payment_method.type.title()
        marketplace_publish_price = publish_subscription.price
        bot_creation_price = creation_subscription.price

        send_new_bot_email(user.email,payment_method_type,order_date,training_cost,payment_session.amount,bot_creation_price,marketplace_publish_price)

        return Response(
            {
                'message': "Payment confirmed",
                'amount_paid': payment_session.amount,
                'tokens_credited': tokens_credited
            },
            status=status.HTTP_200_OK
        )


@extend_schema(
    tags=["Engine"]
)
class EngineViewSet(ModelViewSet):
    queryset = Engine.objects.all()
    serializer_class = EngineSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    http_method_names = ['get', ]


@extend_schema(
    tags=["TrainingMaterial"]
)
class TrainingMaterialViewSet(ModelViewSet):
    queryset = TrainingMaterial.objects.all()
    serializer_class = TrainingMaterialSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    http_method_names = ['get', 'post', 'delete']

    def get_queryset(self):
        return TrainingMaterial.objects.filter(bot__creator=self.request.user)
    
    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        self.perform_destroy(instance)
        return Response(status=status.HTTP_204_NO_CONTENT)

    def perform_destroy(self, instance):
        if (instance.type == TrainingMaterial.Type.URL):
            TrainingMaterial.objects.filter(url__startswith=instance.url, type=TrainingMaterial.Type.CHILDURL).delete()
        instance.delete()

    @extend_schema(
        tags=["TrainingMaterial", "Sublink"]
    )
    @action(
        methods=["post"],
        detail=False,
        url_path="sublink",
        url_name="sublink",
        serializer_class=TrainingMaterialSublinkSerializer
    )
    def update_sublink_materials(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)

        bot = Bot.objects.get(id=serializer.validated_data['bot_id'])

        TrainingMaterial.objects.filter(type=TrainingMaterial.Type.CHILDURL, bot=bot).delete()
        for material in serializer.validated_data['data']:
            TrainingMaterial.objects.create(url=material, type=TrainingMaterial.Type.CHILDURL, bot=bot)

        materials = TrainingMaterial.objects.filter(bot=bot)

        return Response(
            {
                'message': "Success",
                "materials": TrainingMaterialSerializer(materials, many=True).data
            },
            status=status.HTTP_200_OK
        )
