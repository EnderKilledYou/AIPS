from django.contrib import admin
from ..base.admin import BaseAdmin
from .models import Bot, Engine, TrainingMaterial


@admin.register(Engine)
class EngineAdmin(admin.ModelAdmin):
    model = Engine

    list_display = ('name', 'thumbnail', 'created_at', 'modified_at')


@admin.register(Bot)
class BotAdmin(BaseAdmin):
    model = Bot


@admin.register(TrainingMaterial)
class TrainingMaterialAdmin(BaseAdmin):
    model = TrainingMaterial
