from rest_framework.response import Response
from rest_framework import status
from drf_spectacular.utils import extend_schema
from rest_framework.viewsets import ModelViewSet
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.decorators import action

from .models import (
    CreatorToken,
    CreatorTokenHistory,
    BotToken,
    BotTokenHistory
)
from ..Payment.models import PaymentSession, PaymentMethod, PaymentHistory


from .serializers import (
    CreatorTokenSerializer,
    CreatorTokenHistorySerializer,
    BotTokenSerializer,
    BotTokenHistorySerializer,
    CreatorTokenPurchaseSerializer,
    TokenStartPaymentSessionSerializer,
    TokenCompletePaymentSessionSerializer
)

from services.payment import payment_service


@extend_schema(
        tags=["CreatorToken"]
    )
class CreatorTokenViewSet(ModelViewSet):
    queryset = CreatorToken.objects.all()
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    http_method_names = ['get', 'post',]

    def get_serializer_class(self):
        if self.action == 'create':
            return CreatorTokenPurchaseSerializer

        if self.action == 'start_payment_session':
            return TokenStartPaymentSessionSerializer

        if self.action == 'complete_payment_session':
            return TokenCompletePaymentSessionSerializer

        return CreatorTokenSerializer

    def create(self, request, *args, **kwargs):
        user = request.user
        payment_method_id = float(request.data['payment_method_id'])
        amount = float(request.data['amount'])
        try:
            payment_method = PaymentMethod.objects.get(id=payment_method_id)

            if payment_method.owner != user:
                return Response({
                    'message': 'You are not authorized to use the payment method',
                }, status=status.HTTP_400_BAD_REQUEST)

            payment_service.instant_charge(
                amount,
                payment_method.stripe_customer_id,
                payment_method.stripe_payment_method_id,
                metadata={
                    'email': user.email,
                    'source': 'Token purchase'
                }
            )

            PaymentHistory.objects.create(
                payer_email=user.email,
                amount=amount,
                payment_method=payment_method,
                description=f"Token purchase: {user.email}"
            )

            # Credit creator token
            tokens_credited = amount * 10000
            creator_token = CreatorToken.objects.get(user=user)
            creator_token.balance += tokens_credited
            creator_token.save()

            CreatorTokenHistory.objects.create(
                amount=tokens_credited,
                reason="Credit",
                token=creator_token
            )

            return Response({
                'message': 'Payment confirmed',
                'amount_paid': amount,
                'tokens_credited': tokens_credited

            }, status=status.HTTP_200_OK)
        except PaymentMethod.DoesNotExist:
            return Response({
                'message': 'Payment method not found',
            }, status=status.HTTP_404_NOT_FOUND)

    @extend_schema(
        tags=["CreatorToken", "Creator"]
    )
    @action(methods=["post"], detail=False, url_path="start-payment-session", url_name="start-payment-session")
    def start_payment_session(self, request, *args, **kwargs):
        user = request.user
        serializer = self.get_serializer_class()(data=request.data)
        serializer.is_valid(raise_exception=True)

        amount = float(serializer.validated_data['amount'])

        payment_data = {
            'email': user.email,
            'amount': amount,
            'source': 'Token purchase flow'
        }
        session = payment_service.create_payment_session(payment_data)

        payment_session = PaymentSession.objects.create(
            amount=amount,
            status=PaymentSession.Status.PENDING,
            type=PaymentSession.Type.TOKEN_PURCHASE,
            stripe_payment_intent_id=session.id,
            stripe_customer_id=session.customer,
            stripe_client_secret=session.client_secret,
            user=user
        )

        return Response({
            'session_id': payment_session.id,
            'stripe_client_secret': session.client_secret
        }, status=status.HTTP_200_OK)


    @extend_schema(
        tags=["CreatorToken", "Creator"]
    )
    @action(methods=["post"], detail=False, url_path="complete-payment-session", url_name="complete-payment-session")
    def complete_payment_session(self, request, *args, **kwargs):
        user = request.user
        serializer = self.get_serializer_class()(data=request.data)
        serializer.is_valid(raise_exception=True)

        # Check payment was successful
        payment_session = PaymentSession.objects.get(
            id=serializer.validated_data['session_id']
        )
        if payment_session.status == PaymentSession.Status.SUCCESS:
            return Response(
                {'message': "Payment already processed"},
                status=status.HTTP_400_BAD_REQUEST
            )

        success = payment_service.verify_payment_status(
            payment_session.stripe_payment_intent_id,
            payment_session.amount
        )

        if not success:
            return Response(
                {'message': "Unable to verify your payment"},
                status=status.HTTP_400_BAD_REQUEST
            )

        completed_session = payment_service.complete_payment_session(
            payment_session.stripe_payment_intent_id
        )

        try:
            payment_method = PaymentMethod.objects.get(
                stripe_customer_id=completed_session['customer_id'],
                stripe_payment_method_id=completed_session['payment_method_id'],
                owner=user
            )
        except PaymentMethod.DoesNotExist:
            payment_method = PaymentMethod.objects.create(
                type=completed_session['type'],
                email=user.email,
                stripe_customer_id=completed_session['customer_id'],
                stripe_payment_method_id=completed_session['payment_method_id'],
                last4_digits=completed_session['last4_digits'],
                owner=user
            )

        # Create payment history
        PaymentHistory.objects.create(
            payer_email=user.email,
            amount=payment_session.amount,
            payment_method=payment_method,
            description=f"Token purchase"
        )

        # Credit creator token
        tokens_credited = payment_session.amount * 10000
        creator_token = CreatorToken.objects.get(user=user)
        creator_token.balance += tokens_credited
        creator_token.save()

        CreatorTokenHistory.objects.create(
            amount=tokens_credited,
            reason="Credit",
            token=creator_token
        )

        payment_session.status = PaymentSession.Status.SUCCESS
        payment_session.save()

        return Response(
            {
                'message': "Payment confirmed",
                'amount_paid': payment_session.amount,
                'tokens_credited': tokens_credited
            },
            status=status.HTTP_200_OK
        )


@extend_schema(
        tags=["CreatorTokenHistory"]
    )
class CreatorTokenHistoryViewSet(ModelViewSet):
    queryset = CreatorTokenHistory.objects.all()
    serializer_class = CreatorTokenHistorySerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    http_method_names = ['get', ]


@extend_schema(
        tags=["BotToken"]
    )
class BotTokenViewSet(ModelViewSet):
    queryset = BotToken.objects.all()
    serializer_class = BotTokenSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    http_method_names = ['get',"patch"]
    def update(self, request, *args, **kwargs):
        bot_id = kwargs.get('pk')
        bot_token=BotToken.objects.get(bot_id=bot_id)
        user_token=CreatorToken.objects.get(user=request.user)
        if(user_token.balance>=10000):
            bot_token.limit +=10000
            bot_token.save()
            user_token.balance -=10000
            user_token.save()
            return Response("limit increased successfully",status=status.HTTP_200_OK)
        return Response("Not enough token",status=status.HTTP_400_BAD_REQUEST)
   
@extend_schema(
        tags=["BotTokenHistory"]
    )
class BotTokenHistoryViewSet(ModelViewSet):
    queryset = BotTokenHistory.objects.all()
    serializer_class = BotTokenHistorySerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    http_method_names = ['get', ]
