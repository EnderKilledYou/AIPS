from django.apps import AppConfig


class BotConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.Bot'
    label = 'Bot'

    def ready(self):
        from . import signals
        return super().ready()
