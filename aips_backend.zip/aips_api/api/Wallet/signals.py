from django.db.models.signals import post_save
from django.dispatch import receiver

from ..Auth.models import AuthUser

from .models import Wallet


@receiver(post_save, sender=AuthUser)
def post_save_user(sender, instance, **kwargs):
    """
    This method is used as a signal receiver for the post_save signal of the AuthUser model.
    It is called after a user object has been saved.

    Parameters:
        - sender (Model): The sender model that triggered the signal, in this case, AuthUser.
        - instance (AuthUser): The instance of the saved user object.
        - **kwargs: Additional keyword arguments.

    Returns:
        None

    Behavior:
        This method checks if a Wallet object already exists for the provided user instance.
        If a Wallet.DoesNotExist exception is raised, it creates a new Wallet object with the owner
        set to the provided user instance.

    Example usage:
        post_save.connect(post_save_user, sender=AuthUser)
    """
    try:
        Wallet.objects.get(owner=instance)
    except Wallet.DoesNotExist:
        Wallet.objects.create(owner=instance)
