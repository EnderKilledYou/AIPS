# gunicorn.conf.py
# Non logging stuff
bind = "unix:/tmp/api.sock"
workers = 3

LOGGING_PATH = "/home/ubuntu/aips_api/logs"

# Access log - records incoming HTTP requests
accesslog = f"{LOGGING_PATH}/gunicorn-access.log"

# Error log - records Gunicorn server goings-on
errorlog = f"{LOGGING_PATH}/gunicorn-error.log"

# Whether to send Django output to the error log 
capture_output = True

# How verbose the Gunicorn error logs should be 
loglevel = "info"
