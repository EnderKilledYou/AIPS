from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import SupportResultView, UserRankSet, BotRankSet, TagWallSet

router = DefaultRouter()

urlpatterns = router.urls + [
    path('support', SupportResultView.as_view(), name="support-result"),
    path('rank/user', UserRankSet.as_view(), name="user-rank"),
    path('rank/bot', BotRankSet.as_view(), name="bot-rank"),
    path('tagwall', TagWallSet.as_view(), name="tagwall"),
]
