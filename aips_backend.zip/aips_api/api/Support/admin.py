from django.contrib import admin
from ..base.admin import BaseAdmin
from .models import TagWall

@admin.register(TagWall)
class TagWallAdmin(BaseAdmin):
    model = TagWall
