from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
import socket


class EmailSendError(Exception):
    """Raised when there is an error sending the email"""
    pass

def send_signup_email(email, token):
    hostname = socket.gethostname()
    ip_address = socket.gethostbyname(hostname)
    try:
        context = {
            'app_name': settings.APP_NAME,
            'app_domain': settings.APP_DOMAIN,
            'action':'Login',
            'action_url':f'{settings.APP_DOMAIN}/link/register/{token}',
            'IPADDRESS':ip_address
        }
        subject = "Welcome to AIPS.ai"
        html_body = render_to_string("registration_welcome_template/index.html", context=context)
        msg = EmailMultiAlternatives(subject=subject, from_email=settings.EMAIL_FROM_ADDRESS, to=[email], body="")
        msg.attach_alternative(html_body, "text/html")
        try:
            msg.send()
        except Exception as e:
            raise EmailSendError(f"Error sending email: {str(e)}")
    except Exception as e:
        raise Exception(f"An unexpected error occurred: {str(e)}")
    
def send_signin_email(email, token):
    hostname = socket.gethostname()
    ip_address = socket.gethostbyname(hostname)
    
    try:
        context = {
            'app_name': settings.APP_NAME,
            'app_domain': settings.APP_DOMAIN,
            'action':'Login',
            'action_url':f'{settings.APP_DOMAIN}/link/login/{token}',
            'IPADDRESS':ip_address
        }
        subject = "Sign In to Your AIPS.ai Account"
        html_body = render_to_string("login_template/index.html", context=context)
        msg = EmailMultiAlternatives(subject=subject, from_email=settings.EMAIL_FROM_ADDRESS, to=[email], body="")
        msg.attach_alternative(html_body, "text/html")
        try:
            msg.send()
        except Exception as e:
            raise EmailSendError(f"Error sending email: {str(e)}")
    except Exception as e:
        raise Exception(f"An unexpected error occurred: {str(e)}")
    
    

def send_threshold_reached_email(bot):
    try:
        context = {
          "bot":bot
        }
        subject = f"Usage Threshold Reached for Your Bot {bot} on AIPS.ai"
        html_body = render_to_string("treashold_reached_template/index.html", context=context)
        msg = EmailMultiAlternatives(subject=subject, from_email=settings.EMAIL_FROM_ADDRESS,
                                    to=[bot.creator.email], body="")
        msg.attach_alternative(html_body, "text/html")
        try:
            msg.send()
        except Exception as e:
            raise EmailSendError(f"Error sending email: {str(e)}")
    except Exception as e:
        raise Exception(f"An unexpected error occurred: {str(e)}")
    
def send_new_subscription_email(email, bot,subscriber_name):
    try:
        context = {
            'bot': bot or "Bot Name",
            "subscriber_name":subscriber_name
        }
        subject = f"New Subscription for {bot} on {settings.APP_NAME}"
        html_body = render_to_string("new_subscription_template/index.html", context=context)
        msg = EmailMultiAlternatives(subject=subject, from_email=settings.EMAIL_FROM_ADDRESS,
                                    to=[email], body="")
        msg.attach_alternative(html_body, "text/html")
        try:
            msg.send()
        except Exception as e:
            raise EmailSendError(f"Error sending email: {str(e)}")
    except Exception as e:
        raise Exception(f"An unexpected error occurred: {str(e)}")

def send_new_message_email(email, user,bot):
    try:
        bot_image_path="https://aips-middleware-storage.s3.amazonaws.com/media/static/bot/thumbnail/eren_oYb5k4q.jpeg"
        context = {
            'app_name': settings.APP_NAME,
            'app_domain': settings.APP_DOMAIN,
            'user': user,
            'bot':bot or "Bot Name",
            'bot_image':bot_image_path

        }
        subject = f"New Message from {user} - {settings.APP_NAME}"
        html_body = render_to_string("new_message_template/index.html", context=context)
        msg = EmailMultiAlternatives(subject=subject, from_email=settings.EMAIL_FROM_ADDRESS,
                                    to=[email], body="")
        msg.attach_alternative(html_body, "text/html")
        try:
            msg.send()
        except Exception as e:
            raise EmailSendError(f"Error sending email: {str(e)}")
    except Exception as e:
        raise Exception(f"An unexpected error occurred: {str(e)}")

def send_new_bot_email(email, payment_method_type, order_date, training_cost, total_cost,bot_creation_price,marketplace_publish_price):
    hostname = socket.gethostname()
    ip_address = socket.gethostbyname(hostname)

    try:
        context = {
            
            "order_date":order_date,
            "payment_method":payment_method_type,
            "total":total_cost,
            "bot_sub_total":bot_creation_price,
            "token_awarded":10000,
            "training_cost":training_cost,
            "taxes":0,
            'marketplace_publish_price':marketplace_publish_price,
            "ip_address":ip_address

        }
        subject ="Thanks for your purchase!"
        html_body = render_to_string("new_bot/index.html", context=context)
        msg = EmailMultiAlternatives(subject=subject, from_email=settings.EMAIL_FROM_ADDRESS,
                                    to=[email], body="")
        msg.attach_alternative(html_body, "text/html")
        try:
            msg.send()
        except Exception as e:
            raise EmailSendError(f"Error sending email: {str(e)}")
    except Exception as e:
        raise Exception(f"An unexpected error occurred: {str(e)}")
    
def send_bot_training_email(email, bot, train_date, update_train):
    hostname = socket.gethostname()
    ip_address = socket.gethostbyname(hostname)

    try:
        context = {
            'bot_name': bot.name,
            'action_url':f'{settings.APP_DOMAIN}/profile/created-bot/{bot.id}',
            'bot_image': f'{settings.MEDIA_URL}{bot.thumbnail}',
            'train_date': train_date,
            "ip_address":ip_address,
            "title": "Changes you made to your bot has been saved!" if update_train else "Your Bot training is complete!"
        }
        subject = "Bot training"
        html_body = render_to_string("bot_training/index.html", context=context)
        msg = EmailMultiAlternatives(subject=subject, from_email=settings.EMAIL_FROM_ADDRESS, to=[email], body="")
        msg.attach_alternative(html_body, "text/html")
        try:
            msg.send()
        except Exception as e:
            raise EmailSendError(f"Error sending email: {str(e)}")
    except Exception as e:
        raise Exception(f"An unexpected error occurred: {str(e)}")

def send_cashout_email(email, amount, cashout_date, username):
    hostname = socket.gethostname()
    ip_address = socket.gethostbyname(hostname)

    try:
        context = {
            'action': 'Cash out',
            'amount': amount,
            'cashout_date': cashout_date,
            'username': username,
            "ip_address":ip_address
        }
        subject = "Cash Out"
        html_body = render_to_string("cashout_template/index.html", context=context)
        msg = EmailMultiAlternatives(subject=subject, from_email=settings.EMAIL_FROM_ADDRESS, to=[email], body="")
        msg.attach_alternative(html_body, "text/html")
        try:
            msg.send()
        except Exception as e:
            raise EmailSendError(f"Error sending email: {str(e)}")
    except Exception as e:
        raise Exception(f"An unexpected error occurred: {str(e)}")