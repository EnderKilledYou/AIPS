import uuid
import requests
import boto3
from django.conf import settings


class TrainingService:

    def __init__(self):
        self.endpoint = settings.TRAINING_API_HOST
        self.training_bucket = settings.AWS_TRAINING_BUCKET
        self.s3_client = boto3.client(
            's3',
            region_name=settings.AWS_REGION,
            aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
            aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY
        )

    def get_cost(self, bot, flag = "train"):
        user_id = uuid.UUID(int=bot.creator.id)
        training_materials = bot.training_materials.all()

        url_list = []
        for training_material in training_materials:
            if not training_material.url.startswith(f"https://{self.training_bucket}"):
                url_list.append(training_material.url)

        url = f"{settings.DATALOADER_API_HOST}/getCost"
        data = {
            "bucket_name": self.training_bucket,
            "directory": f"{user_id}/",
            "url_list": url_list,
            "bot_ID": str(bot.id),
            "flag": flag
        }
        res = requests.post(url, json=data)
        return round(res.json()['cost'], 2)

    def generate_upload_url(self, bot, file_name):
        key = f"{uuid.UUID(int=bot.creator.id)}/{str(bot.id)}/train/{file_name}"

        url = self.s3_client.generate_presigned_url(
            'put_object',
            Params={
                'Bucket': self.training_bucket,
                'Key': key
            },
            ExpiresIn=3600)

        return url

    def generate_upload_post(self, bot, file_name, update_data):
        if update_data:
            key = f"{uuid.UUID(int=bot.creator.id)}/{str(bot.id)}/update/{file_name}"
        else:
            key = f"{uuid.UUID(int=bot.creator.id)}/{str(bot.id)}/train/{file_name}"

        post = self.s3_client.generate_presigned_post(
            Bucket=settings.AWS_TRAINING_BUCKET,
            Key=key,
            ExpiresIn=3600
        )

        return post


training_service = TrainingService()
