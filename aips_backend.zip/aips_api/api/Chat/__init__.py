default_app_config = 'api.Chat.apps.ChatConfig'
