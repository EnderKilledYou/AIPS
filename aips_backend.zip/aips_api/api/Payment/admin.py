from django.contrib import admin
from ..base.admin import BaseAdmin
from .models import PaymentMethod, PaymentHistory, PaymentSession


@admin.register(PaymentMethod)
class PaymentMethodAdmin(BaseAdmin):
    model = PaymentMethod


@admin.register(PaymentHistory)
class PaymentHistoryAdmin(BaseAdmin):
    model = PaymentHistory


@admin.register(PaymentSession)
class PaymentSessionAdmin(BaseAdmin):
    model = PaymentSession
