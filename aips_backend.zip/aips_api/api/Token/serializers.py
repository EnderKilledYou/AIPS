from rest_framework import serializers
from .models import CreatorToken, CreatorTokenHistory, BotToken, BotTokenHistory
from ..Payment.serializers import StartPaymentSessionSerializer, CompletePaymentSessionSerializer


class CreatorTokenSerializer(serializers.ModelSerializer):

    class Meta:
        model = CreatorToken
        fields = ('balance',)
        read_only_fields = ('balance',)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data


class CreatorTokenHistorySerializer(serializers.ModelSerializer):

    class Meta:
        model = CreatorTokenHistory
        exclude = ('is_deleted',)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data


class BotTokenSerializer(serializers.ModelSerializer):
    class Meta:
        model = BotToken
        exclude = ('is_deleted',)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data


class BotTokenMinimalSerializer(serializers.ModelSerializer):
    class Meta:
        model = BotToken
        fields = ('limit', 'usage', 'metrics')


class BotTokenHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = BotTokenHistory
        exclude = ('is_deleted',)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data


class CreatorTokenPurchaseSerializer(serializers.Serializer):
    payment_method_id = serializers.UUIDField(write_only=True)
    amount = serializers.FloatField(write_only=True)


class TokenStartPaymentSessionSerializer(StartPaymentSessionSerializer):
    amount = serializers.FloatField(write_only=True)


class TokenCompletePaymentSessionSerializer(CompletePaymentSessionSerializer):
    ...
