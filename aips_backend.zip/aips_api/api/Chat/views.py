from django.db.models import Subquery, OuterRef
from rest_framework.decorators import action
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.response import Response
from rest_framework import status
from drf_spectacular.utils import extend_schema
from rest_framework.viewsets import ModelViewSet
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
from django.conf import settings

from ..Bot.models import Bot
from ..Auth.models import AuthUser
from .models import (
    APISMessage,
    BotMessage,
    FeedbackMessage,
    FeedbackChannel
)
from .serializers import (
    AIPSMessageSerializer,
    BotMessageSerializer,
    BotMessageCreateSerializer,
    BotMessageFeedbackSerializer,
    FeedbackMessageSerializer,
    FeedbackChannelSerializer
)
from services.bot import BotService
from ..Subscription.models import Subscription
from utils.email import send_threshold_reached_email


@extend_schema(
        tags=["AIPSMessage"]
    )
class AIPSMessageViewSet(ModelViewSet):
    queryset = APISMessage.objects.all()
    serializer_class = AIPSMessageSerializer
    http_method_names = ['post']

    def create(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)

        data = serializer.validated_data

        try:
            bot = Bot.objects.get(name="AIPS")
        except Bot.DoesNotExist:
            return Response(
                {'message': "Bot not found"},
                status=status.HTTP_400_BAD_REQUEST
            )

        bot_service = BotService(bot)
        language = data['language'] if 'language' in data else 'en'
        response = bot_service.messageWithAIPS(data['prompt_text'], language)

        serializer.validated_data['response_text'] = response['response']
        serializer.validated_data['response_json'] = response
        message = serializer.save()

        return Response(
            self.serializer_class(message).data,
            status=status.HTTP_200_OK
        )


@extend_schema(
        tags=["BotMessage"]
    )
class BotMessageViewSet(ModelViewSet):
    queryset = BotMessage.objects.all()
    serializer_class = BotMessageSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    http_method_names = ['get', 'post', 'put']

    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['bot', ]

    def get_queryset(self):
        return BotMessage.objects.filter(user=self.request.user)

    def get_serializer_class(self):
        if self.action == 'create':
            return BotMessageCreateSerializer
        elif self.action == 'feedback':
            return BotMessageFeedbackSerializer
        else:
            return BotMessageSerializer

    @action(detail=False, methods=['get'], url_path='last-messages')
    def last_messages(self, request, *args, **kwargs):
        bot_id = request.query_params.get('bot')
        if not bot_id:
            return Response({'detail': 'Bot ID is required.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            bot = Bot.objects.get(id=bot_id)
        except Bot.DoesNotExist:
            return Response({'detail': 'Bot not found.'}, status=status.HTTP_404_NOT_FOUND)
        latest_message_ids_subquery = BotMessage.objects.filter(
            bot=bot,
            user_id=OuterRef('user_id')
        ).order_by('-id').values('id')[:1]

        user_messages = BotMessage.objects.exclude(response_text=None).filter(
            id__in=Subquery(latest_message_ids_subquery)
        ).values('user__avatar', 'user__id', 'id', 'user__username', 'response_text', 'created_at')

        for message in user_messages:
            if message['user__avatar']:
                message['user__avatar'] = settings.MEDIA_URL + message['user__avatar']

        return Response(user_messages, status=status.HTTP_200_OK)

    @action(methods=["get"], detail=False, url_path="user-activity")
    def user_activity(self, request, *args, **kwargs):
        bot_id = request.query_params.get('bot')
        if not bot_id:
            return Response({'detail': 'Bot ID is required.'}, status=status.HTTP_400_BAD_REQUEST)

        user_id = request.query_params.get('user')
        if not user_id:
            return Response({'detail': 'User ID is required.'}, status=status.HTTP_400_BAD_REQUEST)

        # Filter BotMessage objects by user_id and bot_id
        messages = BotMessage.objects.filter(user_id=user_id, bot_id=bot_id).order_by('-created_at').values('response_text', 'prompt_text', 'created_at', 'user__avatar', 'bot__thumbnail')
        for message in messages:
            if message['user__avatar']:
                message['user__avatar'] = settings.MEDIA_URL + message['user__avatar']
            if message['bot__thumbnail']:
                message['bot__thumbnail'] = settings.MEDIA_URL + message['bot__thumbnail']

        return Response(messages, status=status.HTTP_200_OK)

    @action(
        methods=["put"],
        detail=True, url_path="feedback",
        url_name="feedback",
        serializer_class=BotMessageFeedbackSerializer
    )
    def feedback(self, request, *args, **kwargs):
        message = self.get_object()

        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        message.feedback = data['feedback']
        message.save()

        return Response(
            self.serializer_class(message).data,
            status=status.HTTP_200_OK
        )

    def create(self, request, *args, **kwargs):
        user = self.request.user
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.validated_data['user'] = user

        data = serializer.validated_data

        try:
            bot = Bot.objects.get(id=serializer.validated_data['bot_id'])
        except Bot.DoesNotExist:
            return Response(
                {'message': "Bot not found"},
                status=status.HTTP_400_BAD_REQUEST
            )

        if bot.creator != user:
            try:
                subscription = Subscription.objects.get(
                    subscriber=user,
                    service__bot=bot,
                    status=Subscription.Status.ACTIVE
                )
            except Subscription.DoesNotExist:
                return Response(
                    {'message': "No active subscription found for the selected bot."},
                    status=status.HTTP_400_BAD_REQUEST
                )
        
        if bot.token.limit != 0 and bot.token.limit <= bot.token.usage:
            send_threshold_reached_email(bot)
            return Response(
                {'message': "Bot spent allocated tokens. Please reach out creator to use the bot"},
                status=status.HTTP_400_BAD_REQUEST
            )

        bot_service = BotService(bot)

        recall = []
        if (bot.retain_conversational_context):
            last_messages = BotMessage.objects.filter(bot=bot, user=user).order_by('-created_at')[:3]
            for msg in reversed(last_messages):
                recall.append(f"User: {msg.prompt_text}")
                recall.append(f"AI: {msg.response_text}")

        language = data['language'] if 'language' in data else 'en'
        response = bot_service.message(data['prompt_text'], recall, language)

        bot_token = bot.token
        spent_token = response['usage']
        if bot_token.limit < bot_token.usage + spent_token:
            bot_token.usage = bot_token.limit
            bot_token.save()

            send_threshold_reached_email(bot)
            return Response(
                {'message': "The bot reached out of limit"},
                status=status.HTTP_400_BAD_REQUEST
            )
        else:
            bot_token.usage += spent_token

        metrics = bot_token.metrics
        if str(user.id) not in metrics:
            metrics[user.id] = {'user_name': user.username, 'usage': spent_token}
        else:
            metrics[str(user.id)]['usage'] += spent_token

        bot_token.metrics = metrics
        bot_token.save()

        serializer.validated_data['response_text'] = response['response']
        serializer.validated_data['response_json'] = response
        message = serializer.save()

        return Response(
            self.serializer_class(message).data,
            status=status.HTTP_200_OK
        )


@extend_schema(
        tags=["FeedbackChannel"]
    )
class FeedbackChannelViewSet(ModelViewSet):
    queryset = FeedbackChannel.objects.all()
    serializer_class = FeedbackChannelSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    http_method_names = ['get', 'post', 'delete']

    def get_queryset(self):
        if self.action == 'creator_channels':
            return FeedbackChannel.objects.filter(bot__creator=self.request.user)

        if self.action == 'user_channels':
            return FeedbackChannel.objects.filter(user=self.request.user)

        return FeedbackChannel.objects.all()

    @action(
        methods=["get"],
        detail=False, url_path="creator-channels",
        url_name="creator-channels",
    )
    def creator_channels(self, request, *args, **kwargs):
        return super().list(request, args, kwargs)

    @action(
        methods=["get"],
        detail=False, url_path="user-channels",
        url_name="user-channels",
    )
    def user_channels(self, request, *args, **kwargs):
        return super().list(request, args, kwargs)

    @action(
        methods=["get",  "post"],
        detail=True, url_path="messages",
        url_name="messages",
        serializer_class=FeedbackMessageSerializer
    )
    def message(self, request, *args, **kwargs):
        channel = self.get_object()
        user = self.request.user

        if user != channel.user and user != channel.bot.creator:
            return Response({"message": "No access to this channel"}, status=status.HTTP_400_BAD_REQUEST)

        if self.request.method == "POST":
            serializer = self.serializer_class(data=request.data)
            serializer.is_valid(raise_exception=True)

            serializer.validated_data['sender'] = user
            serializer.validated_data['channel'] = channel
            message = serializer.save()

            return Response(self.serializer_class(message).data, status=status.HTTP_201_CREATED)
        else:
            messages = FeedbackMessage.objects.filter(channel=channel)
            return Response(self.serializer_class(messages, many=True).data, status=status.HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        user = self.request.user
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        bot_id = serializer.validated_data['bot_id']

        try:
            bot = Bot.objects.get(id=bot_id)
        except Bot.DoesNotExist:
            return Response({"message": "Bot not found"}, status=status.HTTP_400_BAD_REQUEST)

        if user == bot.creator:
            user_id = serializer.validated_data.get('user_id', None)
            if user_id is None:
                return Response({"message": "User id must be specified"}, status=status.HTTP_400_BAD_REQUEST)

            user = AuthUser.objects.get(id=user_id)
            serializer.validated_data['user'] = user
        else:
            serializer.validated_data['user'] = user

        try:
            FeedbackChannel.objects.get(user=user, bot=bot)
            return Response({"message": "Existing channel found"}, status=status.HTTP_409_CONFLICT)
        except FeedbackChannel.DoesNotExist:
            serializer.validated_data['name'] = f"{bot.name}({user.username} <-> {bot.creator.username})"
            serializer.validated_data['subscribers'] = {"creator": bot.creator.id, 'users': [user.id]}
            channel = serializer.save()
            return Response(self.serializer_class(channel).data, status=status.HTTP_201_CREATED)


@extend_schema(
        tags=["FeedbackMessage"]
    )
class FeedbackMessageViewSet(ModelViewSet):
    queryset = FeedbackMessage.objects.all()
    serializer_class = FeedbackMessageSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    http_method_names = ['get', 'post']

    @action(
        methods=["get"],
        detail=False, url_path="channel/<uuid:channel_id>/messages",
        url_name="channel-messages",
    )
    def channel_messages(self, request, channel_id, *args, **kwargs):
        channel = FeedbackChannel.objects.get(id=channel_id)
        messages = FeedbackMessage.objects.filter(channel=channel)
        return Response(self.serializer_class(messages, many=True).data, status=status.HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        user = self.request.user
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        channel_id = serializer.validated_data['channel_id']

        try:
            channel = FeedbackChannel.objects.get(id=channel_id)
        except FeedbackChannel.DoesNotExist:
            return Response({"message": "Channel not found"}, status=status.HTTP_404_NOT_FOUND)

        serializer.validated_data['sender'] = user
        serializer.validated_data['channel'] = channel
        message = serializer.save()

        return Response(self.serializer_class(message).data, status=status.HTTP_201_CREATED)
