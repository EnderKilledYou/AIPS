from drf_spectacular.utils import extend_schema
from rest_framework.viewsets import ModelViewSet
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework import filters

from .models import PaymentMethod, PaymentHistory
from .serializers import PaymentMethodSerializer, PaymentHistorySerializer


@extend_schema(
        tags=["PaymentMethod"]
    )
class PaymentMethodViewSet(ModelViewSet):
    queryset = PaymentMethod.objects.all()
    serializer_class = PaymentMethodSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    http_method_names = ['get',]


@extend_schema(
        tags=["PaymentHistory"]
    )
class PaymentHistoryViewSet(ModelViewSet):
    queryset = PaymentHistory.objects.all()
    serializer_class = PaymentHistorySerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    http_method_names = ['get',]
    filter_backends = [filters.SearchFilter]
    search_fields = ['payer_email', ]
