from drf_spectacular.utils import extend_schema

from rest_framework.response import Response
from rest_framework import status

from rest_framework.generics import ListAPIView
from rest_framework.views import APIView

from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication

from .models import Wallet, WalletHistory
from .serializers import WalletSerializer, WalletHistorySerializer, CashOutSerializer
from services.payment import payment_service
from utils.email import send_cashout_email
from django.utils import timezone


@extend_schema(
    tags=["Wallet"]
)
class MyWalletView(APIView):
    serializer_class = WalletSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        wallet = Wallet.objects.get(owner=self.request.user)

        if not wallet.stripe_account_id:
            account = payment_service.create_connect_account(wallet.owner.email)
            wallet.stripe_account_id = account.id
            wallet.save()

        connect_account = payment_service.get_connect_account_info(wallet.stripe_account_id)

        return Response({
            "wallet": self.serializer_class(wallet).data,
            "history": WalletHistorySerializer(wallet.history, many=True).data,
            "payouts_enabled": connect_account.charges_enabled and connect_account.payouts_enabled
        }, status=status.HTTP_200_OK)
    
@extend_schema(
    tags=["Wallet"]
)
class WalletSessionView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        wallet = Wallet.objects.get(owner=self.request.user)
        account_session = payment_service.generate_payout_session(wallet.stripe_account_id)
        return Response({"client_secret": account_session.client_secret}, status=status.HTTP_200_OK)

@extend_schema(
    tags=["Wallet"]
)
class CashOutView(APIView):
    serializer_class = CashOutSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)

        amount = serializer.validated_data['amount']
        owner = request.user

        wallet = Wallet.objects.get(owner=owner)
        if wallet.balance < amount:
            return Response(
                {"message": "Amount must be less than your balance"},
                status=status.HTTP_406_NOT_ACCEPTABLE
            )

        bank_info = payment_service.create_payout(int(amount * 100), wallet.stripe_account_id)

        wallet.balance -= amount
        wallet.save()

        WalletHistory.objects.create(
            amount=-amount,
            description="Cash out",
            last4_digit=bank_info.last4,
            wallet=wallet
        )

        current_date = timezone.now()
        formatted_date = current_date.strftime('%d %B %Y')

        send_cashout_email(owner.email, amount, formatted_date, owner.username)

        return Response({"message": "success"}, status=status.HTTP_200_OK)


@extend_schema(
        tags=["Wallet"]
    )
class WalletHistoryView(ListAPIView):
    queryset = WalletHistory.objects.all()
    serializer_class = WalletHistorySerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return WalletHistory.objects.filter(wallet__owner=self.request.user)
